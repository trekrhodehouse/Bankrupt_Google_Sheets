'''
    Primary Author (this file) - Corey Buchanan

    Copyright Corey Buchanan, Todd Nielsen, Ian Mogensen, Trek Roadhouse, Zachary Gundersen, Jonah Durtschi,
    CS 3505, April 2021

    This work may not be copied for academic use.

    File Contents -
    Dummy server to simulate handshake by taking a username, sending a list of sample
    spreadsheet names, and recieving the name of a spreadsheet to edit. Any other input
    is echoed back with a slight (purposefully simulated) delay of 1 second.

    Note - messages recieved come with a newline character, this server trims them off
'''

import asyncio
import time

HOST = "127.0.0.1"
PORT = 1100

async def handle_echo(reader, writer):
    username = await reader.read(1024)

    if not username:
        return

    username = username.decode('utf-8').rstrip()

    print(f"{username} has connected")

    spreadsheet_names = "test\ntest2\ntest3\n\n"

    writer.write(spreadsheet_names.encode("utf-8"))
    await writer.drain()

    spreadsheet_name = await reader.read(1034)

    if not spreadsheet_name:
        return

    print(f"Spreadsheet opened: {spreadsheet_name.decode('utf-8').rstrip()}")

    client_id = "123\n"

    writer.write(client_id.encode("utf-8"))

    while True:
        data = await reader.read(1024)

        if not data:
            break

        message = data.decode("utf-8").rstrip()
        address = writer.get_extra_info('peername')
        print(f"Recieved {message} from {username}");

        time.sleep(1)

        writer.write(message.encode("utf-8"))
        await writer.drain()

loop = asyncio.get_event_loop()
server_handler = asyncio.start_server(handle_echo, HOST, PORT, loop=loop)

try:
    server = loop.run_until_complete(server_handler)
    loop.run_forever()
except KeyboardInterrupt:
    server.close()
    loop.run_until_complete(server.wait_closed())
    loop.close()
'''
    Copyright Corey Buchanan, Todd Nielsen, Ian Mogensen, Trek Roadhouse, Zachary Gundersen, Jonah Durtschi,
    CS 3505, April 2021

    This work may not be copied for academic use.

    File Contents -
    Spreadsheet Tester, runs <test #> specified by user on spreadsheet server.

    Usage:
        To get the number of tests:
            ./spreadsheet_tester
        To run a specific test:
            ./spreadsheet_tester <test #> <hostname:port>

'''

import asyncio
import async_timeout
import sys
import re
import json

timeout_length = 10
num_tests = 4


async def test_1(reader, writer):
    print("Basic Editing Cells")

    message = '{requestType: "selectCell", cellName: "A1"}\n'
    writer.write(message.encode("utf-8"))
    message = '{requestType: "editCell", cellName: "A1", cellContents: ""}\n'
    writer.write(message.encode("utf-8"))
    await reader.read(1024)
    message = '{requestType: "selectCell", cellName: "B1"}\n'
    writer.write(message.encode("utf-8"))
    message = '{requestType: "editCell", cellName: "B1", cellContents: ""}\n'
    writer.write(message.encode("utf-8"))
    await reader.read(1024)

    message = '{requestType: "selectCell", cellName: "A1"}\n'
    writer.write(message.encode("utf-8"))
    message = '{requestType: "editCell", cellName: "A1", cellContents: "=B1"}\n'
    writer.write(message.encode("utf-8"))

    data = await reader.read(1024)
    data_string = data.decode("utf-8")
    data_string = re.sub("(\w+):", r'"\1":',  data_string)
    json_data = json.loads(data_string)

    if json_data['messageType'] != "updateCell" or json_data['cellName'] != "A1" or json_data['cellContents'] != "=B1":
        print("Fail")
        sys.exit(1)

    message = '{requestType: "selectCell", cellName: "B1"}\n'
    writer.write(message.encode("utf-8"))
    message = '{requestType: "editCell", cellName: "B1", cellContents: "=4"}\n'
    writer.write(message.encode("utf-8"))

    data = await reader.read(1024)
    data_string = data.decode("utf-8")
    data_string = re.sub("(\w+):", r'"\1":',  data_string)
    json_data = json.loads(data_string)

    if json_data['messageType'] != "updateCell" or json_data['cellName'] != "B1" or json_data['cellContents'] != "=4":
        print("Fail")
        sys.exit(1)

    message = '{requestType: "selectCell", cellName: "A1"}\n'
    writer.write(message.encode("utf-8"))
    message = '{requestType: "editCell", cellName: "A1", cellContents: "string"}\n'
    writer.write(message.encode("utf-8"))

    data = await reader.read(1024)
    data_string = data.decode("utf-8")
    data_string = re.sub("(\w+):", r'"\1":',  data_string)
    json_data = json.loads(data_string)

    if json_data['messageType'] != "updateCell" or json_data['cellName'] != "A1" or json_data['cellContents'] != "string":
        print("Fail")
        sys.exit(1)

    print("Pass")




async def test_2(reader, writer):
    print("Basic Undo and Revert")

    message = '{requestType: "selectCell", cellName: "A1"}\n'
    writer.write(message.encode("utf-8"))
    message = '{requestType: "editCell", cellName: "A1", cellContents: ""}\n'
    writer.write(message.encode("utf-8"))
    await reader.read(1024)
    message = '{requestType: "selectCell", cellName: "B1"}\n'
    writer.write(message.encode("utf-8"))
    message = '{requestType: "editCell", cellName: "B1", cellContents: ""}\n'
    writer.write(message.encode("utf-8"))
    await reader.read(1024)

    message = '{requestType: "selectCell", cellName: "A1"}\n'
    writer.write(message.encode("utf-8"))
    message = '{requestType: "editCell", "cellName": "A1", cellContents: "=B1"}\n'
    writer.write(message.encode("utf-8"))

    data = await reader.read(1024)
    data_string = data.decode("utf-8")
    data_string = re.sub("(\w+):", r'"\1":',  data_string)
    json_data = json.loads(data_string)

    if json_data['messageType'] != "updateCell" or json_data['cellName'] != "A1" or json_data['cellContents'] != "=B1":
        print("Fail")
        sys.exit(1)

    message = '{requestType: "selectCell", cellName: "B1"}\n'
    writer.write(message.encode("utf-8"))
    message = '{requestType: "editCell", cellName: "B1", cellContents: "=4"}\n'
    writer.write(message.encode("utf-8"))

    data = await reader.read(1024)
    data_string = data.decode("utf-8")
    data_string = re.sub("(\w+):", r'"\1":',  data_string)
    json_data = json.loads(data_string)

    if json_data['messageType'] != "updateCell" or json_data['cellName'] != "B1" or json_data['cellContents'] != "=4":
        print("Fail")
        sys.exit(1)

    message = '{requestType: "selectCell", cellName: "A1"}\n'
    writer.write(message.encode("utf-8"))
    message = '{requestType: "editCell", cellName: "A1", cellContents: "=string"}\n'
    writer.write(message.encode("utf-8"))

    data = await reader.read(1024)
    data_string = data.decode("utf-8")
    data_string = re.sub("(\w+):", r'"\1":',  data_string)
    json_data = json.loads(data_string)

    if json_data['messageType'] != "updateCell" or json_data['cellName'] != "A1" or json_data['cellContents'] != "string":
        print("Fail")
        sys.exit(1)

    message = '{requestType: "revert", cellName: "A1"}\n'
    writer.write(message.encode("utf-8"))

    data = await reader.read(1024)
    data_string = data.decode("utf-8")
    data_string = re.sub("(\w+):", r'"\1":',  data_string)
    json_data = json.loads(data_string)

    if json_data['messageType'] != "updateCell" or json_data['cellName'] != "A1" or json_data['cellContents'] != "=B1":
        print("Fail")
        sys.exit(1)

    message = '{requestType: "undo"}\n'
    writer.write(message.encode("utf-8"))

    data = await reader.read(1024)
    data_string = data.decode("utf-8")
    data_string = re.sub("(\w+):", r'"\1":',  data_string)
    json_data = json.loads(data_string)

    if json_data['messageType'] != "updateCell" or json_data['cellName'] != "A1" or json_data['cellContents'] != "string":
        print("Fail")
        sys.exit(1)

    message = '{requestType: "undo", cellName: "A1"}\n'
    writer.write(message.encode("utf-8"))

    data = await reader.read(1024)
    data_string = data.decode("utf-8")
    data_string = re.sub("(\w+):", r'"\1":',  data_string)
    json_data = json.loads(data_string)

    if json_data['messageType'] != "updateCell" or json_data['cellName'] != "B1" or json_data['cellContents'] != "":
        print("Fail")
        sys.exit(1)

    print("Pass")

async def test_3(reader, writer):
    print("Create Circular Dependency")

    message = '{requestType: "selectCell", cellName: "A1"}\n'
    writer.write(message.encode("utf-8"))
    message = '{requestType: "editCell", cellName: "A1", cellContents: ""}\n'
    writer.write(message.encode("utf-8"))

    message = '{requestType: "selectCell", cellName: "B1"}\n'
    writer.write(message.encode("utf-8"))
    message = '{requestType: "editCell", cellName: "B1", cellContents: ""}\n'
    writer.write(message.encode("utf-8"))

    message = '{requestType: "selectCell", cellName: "A1"}\n'
    writer.write(message.encode("utf-8"))

    data = await reader.read(1024)
    data_string = data.decode("utf-8")
    data_string = re.sub("(\w+):", r'"\1":',  data_string)
    json_data = json.loads(data_string)

    if json_data['messageType'] != "updateCell" or json_data['cellName'] != "A1" or json_data['cellContents'] != "=B1":
        print("Fail")
        sys.exit(1)

    message = '{requestType: "selectCell", cellName: "B1"}\n'
    writer.write(message.encode("utf-8"))
    message = '{requestType: "editCell", cellName: "B1", cellContents: "=A1"}\n'
    writer.write(message.encode("utf-8"))

    data = await reader.read(1024)
    data_string = data.decode("utf-8")
    data_string = re.sub("(\w+):", r'"\1":',  data_string)
    json_data = json.loads(data_string)

    if json_data['messageType'] != "requestError":
        print("Fail")
        sys.exit(1)

    print("Pass")


async def test_4(reader, writer):
    print("Send Bad Syntax")

    message = '{requestType: "editGarbage" cellName: 1"990nts: "=4"}\n'
    writer.write(message.encode("utf-8"))

    data = await reader.read(1024)
    data_string = data.decode("utf-8")
    data_string = re.sub("(\w+):", r'"\1":',  data_string)
    json_data = json.loads(data_string)

    if json_data['messageType'] != "requestError":
        print("Fail")
        sys.exit(1)

    print("Pass")


async def connect(test_number, hostname, port):
    with async_timeout.timeout(timeout_length):
        reader, writer = await asyncio.open_connection(hostname, port)

        # Handshake
        name = f"user_test{test_number}\n"
        # print(name)
        writer.write(name.encode("utf-8"))

        await writer.drain()

        spreadsheet_names = ""

        while not "\n\n" in spreadsheet_names:
            data = await reader.read(1024)
            spreadsheet_names += data.decode("utf-8")

        spreadsheet = f"test_spreadsheet{test_number}\n"

        writer.write(spreadsheet.encode("utf-8"))

        spreadsheet_data = ""

        int_with_newline = re.compile("\d+\n")

        while not int_with_newline.search(spreadsheet_data):
            data = await reader.read(1024)
            spreadsheet_data += data.decode("utf-8")

        if test_number == 1:
            await test_1(reader, writer)
        elif test_number == 2:
            await test_2(reader, writer)
        elif test_number == 3:
            await test_3(reader, writer)
        elif test_number == 4:
            await test_4(reader, writer)


# Main

if len(sys.argv) == 1:
    print(num_tests)
    sys.exit(0)

if len(sys.argv) != 3:
    print("Usage ./spreadsheet_tester")
    print("or")
    print("./spreadsheet_tester <test_number> <hostname:port>")
    sys.exit(0)

test_number = int(sys.argv[1])

hostname = sys.argv[2].split(":")[0]
port = sys.argv[2].split(":")[1]

print(timeout_length)

asyncio.run(connect(test_number, hostname, port))

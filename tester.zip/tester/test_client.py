'''
    Primary Author (this file) - Corey Buchanan

    Copyright Corey Buchanan, Todd Nielsen, Ian Mogensen, Trek Roadhouse, Zachary Gundersen, Jonah Durtschi,
    CS 3505, April 2021

    This work may not be copied for academic use.

    File Contents -
    Testing script for connecting to the spreadsheet server, allows user to input commands
    and view messages recieved from server.
'''

import asyncio
import concurrent.futures
import sys

HOST = "127.0.0.1"
PORT = 1100

async def send_messages(writer):
    executor = concurrent.futures.ThreadPoolExecutor()

    print("Type 'commands' for a list of commands or exit to exit the client.")

    while True:
        user_request = await asyncio.get_event_loop().run_in_executor(executor, input)
        request = ""
        user_request_params = user_request.split(" ")

        if user_request_params[0] == "":
            pass
        elif user_request_params[0] == "exit":
            sys.exit(0)
        elif user_request_params[0] == "commands":
            print("---- Command Listing ----")
            print("Edit Cell - Usage: editCell <cellname> <contents>")
            print("Revert Cell - Usage: revertCell <cellname>")
            print("Select Cell - Usage: selectCell <cellname>")
            print("Undo - Usage: undo")
            print("----- End Listing ------")
        elif user_request_params[0] == "editCell":
            if len(user_request_params) != 3:
                print("Usage: editCell <cellname> <contents>")
            else:
                request = "{requestType: \"editCell\", cellName: " + user_request_params[1] + ", contents:" + user_request_params[2] + "}\n"
        elif user_request_params[0] == "revertCell":
            if len(user_request_params) != 2:
                print("Usage: revertCell <cellname>")
            else:
                request = "{requestType: \"revertCell\", cellName: " + user_request_params[1] + "}\n"
        elif user_request_params[0] == "selectCell":
            if len(user_request_params) != 2:
                print("Usage: selectCell <cellname>")
            else:
                request = "{requestType: \"selectCell\", cellName: " + user_request_params[1] + "}\n"
        elif user_request_params[0] == "undo":
            if len(user_request_params) != 1:
                print("Usage: undo")
            else:
                request = "{requestType: \"undo\"}\n"
        else:
            print(f"Invalid command: {user_request_params[0]}")

        if request != "":
            writer.write(request.encode("utf-8"))
            await writer.drain()

async def recieve_messages(reader):
    while True:
        data = await reader.read(1024)
        if not data:
            break

        print(data.decode("utf-8"))

async def connect():
    reader, writer = await asyncio.open_connection(HOST, PORT)

    # Handshake
    name = input("Username: ")
    name += "\n"
    writer.write(name.encode("utf-8"))

    await writer.drain()

    spreadsheet_names = ""

    while not "\n\n" in spreadsheet_names:
        data = await reader.read(1024)
        spreadsheet_names += data.decode("utf-8")

    spreadsheet_list = spreadsheet_names.split("\n")
    print(f"Files: {spreadsheet_list}")

    spreadsheet = input("Select spreadsheet: ")
    spreadsheet += "\n"

    writer.write(spreadsheet.encode("utf-8"))
    await writer.drain()

    print(f"Welcome {name.rstrip()}, you are editing {spreadsheet.rstrip()}.")

    # IO Loops

    task1 = asyncio.create_task(send_messages(writer))
    task2 = asyncio.create_task(recieve_messages(reader))

    await task1
    await task2


# Main

asyncio.run(connect())


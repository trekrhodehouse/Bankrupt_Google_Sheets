#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <map>
#include <algorithm>
#include <boost/algorithm/string.hpp> // for splitting string on \n. maybe better alternative out there
#include <sstream>
#include <iterator>
#include <regex>
#include <boost/asio.hpp>
#include <json/json.h>
#include <pthread.h>
#include <dirent.h>
#include "Spreadsheet.h"
#include "Revert.h"

#define PORT 1100

/*
  Invariant - this path is not to contain any sub-folders, shouldn't be a problem
  if this program is the only one to manipulate the contents of the folder.
*/
#define SPREADSHEET_PATH "./spreadsheets/"

using boost::asio::ip::tcp;

/*
  Gets a list of spreadsheets from the directory
  specified by SPREADSHEET_PATH
*/
std::vector<std::string>* get_spreadsheet_list();

/*
  Given a list of spreadsheets, builds a string that can
  be sent to the clients for selection.
*/
std::string build_spreadsheet_string(std::vector<std::string>* strings);
/*
  Given a commma separated file of the form (one cell per line):
  undos
  cell_1,""
  cell_1,first_state
  cell_2,""
  cell_1,second_state
  reverts
  cell_1,first_state,second_state,third_state
  cell_2,first_state
  parses the contents into a change object from which a spreadsheet
  can be built
*/
spreadsheet::spreadsheet* open_spreadsheet_file(std::string filename);

/*
  Opens a spreadsheet file and sends the data to the client.
  TODO - Add blocking mechanism to this and other functions to ensure
  no other client can edit the spreadsheet while the client is still recieving
  data for this spreadsheet.
*/
void client_open_spreadsheet(int client_id, std::string filename);

/*
  Handler for a select cell request, informs all clients with the spreadsheet
  currently open.
*/
void client_select_cell(int client_id, std::string cell_name);

/*
  Handler for an edit cell request, informs all clients with the spreadsheet
  currently open. Sends an error message if a bad request is made. Ignores request
  if cell is not selected by client.
*/
void client_edit_cell(int client_id, std::string cell_name, std::string cell_contents);

/* Handles a revert request */
void client_revert(int client_id, std::string cell_name);

/* Handles an undo request */
void client_undo(int client_id);

/* Closes a spreadsheet when a client connection is closed or lost */
void client_close_spreadsheet(int client_id);

/*
  Given a message from the client (not during the handhake), deserialize the JSON
  and send data to the currect function for handling.
*/
void decode_and_handle(int client_id, std::string message);

/*
  Given data to send to the client, this function serializes it into JSON format.
  Ensures a newline at the end of the string
*/
std::string encode(std::string messageType, std::string cellName, std::string cellContents, std::string message, int user = 0);

/* Given a list of cells, adds a spreadsheet to the list */

/* Given a spreadsheet object and a filename, writes to a file */
void write_file(std::string filename, spreadsheet::spreadsheet* spreadsheet);

/* Sends a requestError message to the client when client doesn't provide enough JSON data */
void send_bad_request(int client_id);


static long long nextID = 0;
struct socket_state;
using callback = std::function<void()>;

struct user_info
{
	socket_state* state;  // Filled in during handshake
	std::string username; // Filled in during handshake
	std::string filename; // Filled in by client_open_spreadsheet()
	spreadsheet::spreadsheet* open_spreadsheet; // Filled in by client_open_spreadsheet()
	std::string cell_selected = ""; // Filled in by client_select_cell()
};

//std::mutex mtx_map;
// Client ID->Opened Spreadsheet Info
std::map<int, user_info> info_by_client_id;
// Filename->Client IDs
std::map<std::string, std::vector<int>> clients_using_spreadsheet;

struct socket_state : std::enable_shared_from_this<socket_state>
{
public:
	std::mutex mtx;
	callback _callback;
	tcp::socket the_socket;
	long long ID;

	const int buffer_size = 4096;                              // Size of receive buffer
	//char buffer[4096]{}; //
	std::vector<char> buffer = std::vector<char>(buffer_size); // Receive buffer
	std::string data;                                          // Unprocessed data

	template <typename executor>
	socket_state(callback cb, executor ex) : _callback(cb), the_socket(ex)
	{
	}

	void on_network_action(callback cb)
	{
		_callback = cb; // set function to whatever
	}

	std::string get_buffer()
	{
		std::string retval;

		mtx.lock();
		retval = data;
		mtx.unlock();

		return retval;
	}

	void remove_data(int start, int length)
	{
		mtx.lock();
		data.erase(start, length);
		mtx.unlock();
	}

	void send(std::string str)
	{
		std::string* permanent = new std::string(str); // memory leak easter egg
		std::cout << "Sending..." << std::endl;
		auto self(shared_from_this());
		// read from socket stream, begin async process of receiving data using receivecallback to finalize+store data once it arrives
		boost::asio::async_write(the_socket, boost::asio::buffer(*permanent, permanent->size() + 1),
			[this, self, permanent](boost::system::error_code ec, std::size_t bytes_transferred) {
				if (!ec)
				{
					//the_socket.shutdown(tcp::socket::shutdown_send); // finalize send process
				}
				else
				{
					the_socket.close();
					if (clients_using_spreadsheet.count(info_by_client_id.at(ID).filename) > 0) {
						// remove element from clients using spreadsheet that corresponds to the client's ID					
						std::remove(clients_using_spreadsheet.at(info_by_client_id.at(ID).filename).begin(),
							clients_using_spreadsheet.at(info_by_client_id.at(ID).filename).end(), ID);
						info_by_client_id.erase(ID);
					}
				}
				delete permanent;
			});
	}

	void receive_name(std::size_t bytes_transferred)
	{
		std::cout << "Next receive name..." << std::endl;

		// get bytecount of message
		int bytecount = bytes_transferred; // TODO: probably ok but keep an eye here til testing proves otherwise

		if (bytecount == 0)
		{
			auto self(shared_from_this()); // TODO understand this
		// read from socket stream, begin async process of receiving data using receivecallback to finalize+store data once it arrives
			the_socket.async_read_some(boost::asio::buffer(buffer, buffer.size()),
				[this, self](boost::system::error_code ec, std::size_t bytes_transferred) {
					if (!ec)
					{
						receive_name(bytes_transferred);
					}
					else
					{
						if (clients_using_spreadsheet.count(info_by_client_id.at(ID).filename) > 0) {
							// remove element from clients using spreadsheet that corresponds to the client's ID
							std::remove(clients_using_spreadsheet.at(info_by_client_id.at(ID).filename).begin(),
								clients_using_spreadsheet.at(info_by_client_id.at(ID).filename).end(), ID);
							// probably not necessary, remove client from map of clients (IDs are never reused, so)
							info_by_client_id.erase(ID);
							std::cout << "Error in get data..." << std::endl;
							return;
						}
					}
				});
			return;
		}

		std::string message;
		// Convert byte array from result to string
		message.append(buffer.cbegin(), buffer.cend());

		mtx.lock();
		data = message;
		mtx.unlock();

		std::vector<std::string> buf;
		// split into elements on every newline
		boost::algorithm::split(buf, get_buffer(), boost::algorithm::is_any_of("\n"));

		// buffer must include at least 1 full message i.e. has >= 1 newline
		if (!buf.empty())
		{
			std::string username = buf.at(0);
			remove_data(0, username.length() + 1); // +1 takes separator into account

			info_by_client_id.at(ID).username = username; // set user's name
			std::cout << "Received name: " << info_by_client_id.at(ID).username << std::endl;


			// store list of filenames into single newline separated string
			std::string filenames = build_spreadsheet_string(get_spreadsheet_list());

			// send all filenames
			send(filenames);
		}

		auto self(shared_from_this()); // TODO understand this
		// read from socket stream, begin async process of receiving data using receivecallback to finalize+store data once it arrives
		the_socket.async_read_some(boost::asio::buffer(buffer, buffer_size),
			[this, self](const boost::system::error_code ec, std::size_t bytes_transferred) {
				if (!ec)
				{
					receive_filename(bytes_transferred);
				}
				else
				{
					if (clients_using_spreadsheet.count(info_by_client_id.at(ID).filename) > 0) {
						// remove element from clients using spreadsheet that corresponds to the client's ID					
						std::remove(clients_using_spreadsheet.at(info_by_client_id.at(ID).filename).begin(),
							clients_using_spreadsheet.at(info_by_client_id.at(ID).filename).end(), ID);
						// probably not necessary, remove client from map of clients (IDs are never reused, so)
						info_by_client_id.erase(ID);
						std::cout << "Error in get data..." << std::endl;
						return;
					}
				}
			});
	}

	void receive_filename(std::size_t bytes_transferred)
	{
		std::cout << "Receive filename..." << std::endl;

		std::string message;
		// Convert byte array from result to string
		message.append(buffer.cbegin(), buffer.cend());

		mtx.lock();
		data = message;
		mtx.unlock();

		std::vector<std::string> buf;
		// split into elements on every newline
		boost::algorithm::split(buf, get_buffer(), boost::algorithm::is_any_of("\n"));

		// buffer must include at least 1 message
		if (!buffer.empty())
		{
			std::string filename = buf.at(0);
			remove_data(0, filename.length() + 1); // +1 takes separator into account

			vector<int> client_ids{};

			// Pair filename with list of client IDs
			std::pair<std::string, std::vector<int>> pair;
			pair.first = filename;
			pair.second = std::vector<int>(client_ids);
			clients_using_spreadsheet.insert(pair);

			// send all cell contents, cell select info and ID while locking
			client_open_spreadsheet(ID, filename);
		}

		auto self(shared_from_this()); // TODO understand this
		// read from socket stream, begin async process of receiving data using receivecallback to finalize+store data once it arrives
		the_socket.async_read_some(boost::asio::buffer(buffer, buffer.size()),
			[this, self](boost::system::error_code ec, std::size_t bytes_transferred) {
				if (!ec)
				{
					receive_data(bytes_transferred);
				}
				else
				{
					if (clients_using_spreadsheet.count(info_by_client_id.at(ID).filename) > 0) {
						// remove element from clients using spreadsheet that corresponds to the client's ID
						std::remove(clients_using_spreadsheet.at(info_by_client_id.at(ID).filename).begin(),
							clients_using_spreadsheet.at(info_by_client_id.at(ID).filename).end(), ID);
						// probably not necessary, remove client from map of clients (IDs are never reused, so)
						info_by_client_id.erase(ID);
						std::cout << "Error in get data..." << std::endl;
						return;
					}
				}
			});
	}

	void receive_data(std::size_t bytes_transferred)
	{
		std::cout << "Receive data..." << std::endl;

		std::string message;
		// Convert byte array from result to string
		message.append(buffer.cbegin(), buffer.cend());

		mtx.lock();
		data = message;
		mtx.unlock();

		std::vector<std::string> buf;

		// split into elements on every newline
		boost::algorithm::split(buf, socket_state::get_buffer(), boost::algorithm::is_any_of("\n"));
		if (!buffer.empty())
		{
			message = buf.at(0);

			// remove this portion as it will have been accounted for with decode_and_handle
			remove_data(0, message.length() + 1); // +1 takes separator into account

			decode_and_handle(ID, message);
		}

		auto self(shared_from_this()); // TODO understand this
		// read from socket stream, begin async process of receiving data using receivecallback to finalize+store data once it arrives
		the_socket.async_read_some(boost::asio::buffer(buffer, buffer.size()),
			[this, self](boost::system::error_code ec, std::size_t bytes_transferred) {
				if (!ec)
				{
					receive_data(bytes_transferred);
				}
				else
				{
					if (clients_using_spreadsheet.count(info_by_client_id.at(ID).filename) > 0) {
						// remove element from clients using spreadsheet that corresponds to the client's ID
						std::remove(clients_using_spreadsheet.at(info_by_client_id.at(ID).filename).begin(),
							clients_using_spreadsheet.at(info_by_client_id.at(ID).filename).end(), ID);
						// probably not necessary, remove client from map of clients (IDs are never reused, so)
						info_by_client_id.erase(ID);
						std::cout << "Error in get data..." << std::endl;
						return;
					}
				}
			});
	}

	void new_client_connected()
	{
		// only add the bad boi once
		if (info_by_client_id.count(ID) <= 0) {
			std::cout << "went through " << ID << std::endl;
			user_info new_client_info;
			new_client_info.state = this;

			std::pair<int, user_info> id_pairing;
			id_pairing.first = ID;
			id_pairing.second = new_client_info;

			info_by_client_id.insert(id_pairing);
		}

		auto self(shared_from_this()); // TODO understand this
		// read from socket stream, begin async process of receiving data using receivecallback to finalize+store data once it arrives
		the_socket.async_read_some(boost::asio::buffer(buffer, buffer.size()), // TODO
			[this, self](const boost::system::error_code ec, std::size_t bytes_transferred) {
				if (!ec)
				{
					receive_name(bytes_transferred);
				}
				else
				{
					if (clients_using_spreadsheet.count(info_by_client_id.at(ID).filename) > 0) {
						// remove element from clients using spreadsheet that corresponds to the client's ID
						std::remove(clients_using_spreadsheet.at(info_by_client_id.at(ID).filename).begin(),
							clients_using_spreadsheet.at(info_by_client_id.at(ID).filename).end(), ID);
						// probably not necessary, remove client from map of clients (IDs are never reused, so)
						info_by_client_id.erase(ID);
						std::cout << "Error in get data..." << std::endl;
						return;
					}
				}
			});
	}

	//void process_message() {
	//	std::string message;
	//	// Convert byte array from result to string
	//	message.append(buffer.cbegin(), buffer.cend());

	//	mtx.lock();
	//	data.append(message);
	//	mtx.unlock();

	//	std::vector<std::string> buf;
	//	// split into elements on every newline
	//	boost::algorithm::split(buf, socket_state::get_buffer(), boost::algorithm::is_any_of("\n"));

	//	for (std::string str : buf) {
	//		if (str.size() == 0)

	//	}
	//	// buffer must include at least 1 full message i.e. has >= 1 newline
	//	if (!buf.empty())
	//	{
	//		std::string username = buf.at(0);
	//		socket_state::remove_data(0, username.length() + 1); // +1 takes separator into account
	//	}
	//}
};

class spreadsheet_server
{
public:
	using state_ptr = std::shared_ptr<socket_state>;

	explicit spreadsheet_server(boost::asio::io_context& _context, callback cb) : context(_context), _callback(cb)
	{
	}
	boost::asio::io_context& context;
	tcp::acceptor acceptor{ context, {{}, PORT} };
	callback _callback;


	void start_server()
	{
		std::cout << "Server starting..." << std::endl;
		// Start listening for clients
		acceptor.listen();
		// Start client connection loop
		wait_for_client();
	}

	void wait_for_client()
	{
		// executor is the socket tied to the "execution" of this all
		auto state = std::make_shared<socket_state>(_callback, context.get_executor());

		acceptor.async_accept(state->the_socket, std::bind(&spreadsheet_server::accept_new_client, this, state, std::placeholders::_1));
	}

	void accept_new_client(state_ptr state, boost::system::error_code ec)
	{
		if (!ec)
		{
			std::cout << "accept_new_client " << state->the_socket.remote_endpoint() << std::endl;
			state->ID = nextID++; // as soon as a client joins, set its ID
			state->new_client_connected();
		}
		spreadsheet_server::wait_for_client();
	}

	void stop_server()
	{
		std::cout << "Shutting down server." << std::endl;
		acceptor.cancel();
		acceptor.close();
	}
};
//
//int main(int argc, char** argv)
//{
//	std::cout << "Starting spreadsheet server on port " << PORT << ":" << std::endl;
//
//	/*===================== Some testing snippets =====================*/
//	//std::vector<std::string>* spreadsheet_list = get_spreadsheet_list();
//	//std::cout << build_spreadsheet_string(spreadsheet_list) << std::endl;
//	//open_spreadsheet_file(spreadsheet_list->at(0));
//	/*=================================================================*/
//
//	// Set up io context and server
//	boost::asio::io_context context;
//	spreadsheet_server server(context, []() {
//		});
//
//	// Start server listening & handshake process
//	server.start_server();
//
//	// thread that checks for server shutdown input
//	std::thread thread{
//	   [&server] {
//		 std::string input;
//		 while (std::cin >> input) {
//		   if (input == "shutdown") {
//				std::cout << "Shutting down server.\n";
//				server.stop_server();
//				exit(0);
//		   }
//		 }
//	   }
//	};
//
//	context.run();
//
//	return 0;
//}



int main(int argc, char** argv)
{
	std::cout << "Starting spreadsheet server on port " << PORT << ":" << std::endl;

	/*===================== Some testing snippets =====================*/
	//std::vector<std::string>* spreadsheet_list = get_spreadsheet_list();
	//std::cout << build_spreadsheet_string(spreadsheet_list) << std::endl;
	//open_spreadsheet_file(spreadsheet_list->at(0));
	/*=================================================================*/

	// Set up io context and server
	boost::asio::io_context context;
	spreadsheet_server server(context, []() {
		});

	// Start server listening & handshake process
	server.start_server();

	// thread that checks for server shutdown input
	std::thread thread{
	   [&server] {
		 std::string input;
		 while (std::cin >> input) {
		   if (input == "shutdown") {
				std::cout << "Shutting down server.\n";
				server.stop_server();
				exit(0);
		   }
		 }
	   }
	};

	context.run();

	return 0;
}


std::vector<std::string>* get_spreadsheet_list()
{
	DIR* dir;
	struct dirent* dir_read;

	std::vector<std::string>* spreadsheets = new std::vector<std::string>();

	if ((dir = opendir(SPREADSHEET_PATH)) != NULL)
	{
		while ((dir_read = readdir(dir)) != NULL)
		{
			std::string spreadsheet = dir_read->d_name;

			if (spreadsheet != "." && spreadsheet != "..") // Ignore current and previous directory dots
				spreadsheets->push_back(spreadsheet);
		}
	}
	else
	{
		// Normally we'd throw and handle the error, but the spreadsheet directory
		// not being accessable would be fatal to the operation of the server.
		perror("opendir");
		std::cout << "Spreadsheet directory inaccessable" << std::endl;
		exit(1);
	}

	return spreadsheets;
}

std::string build_spreadsheet_string(std::vector<std::string>* strings)
{

	std::string spreadsheet_string = "";

	for (int i = 0; i < strings->size(); i++)
	{
		spreadsheet_string += strings->at(i) + "\n";
	}

	spreadsheet_string += "\n";

	return spreadsheet_string;
}

spreadsheet::spreadsheet* open_spreadsheet_file(std::string filename)
{
	std::string full_filename = SPREADSHEET_PATH + filename;

	std::ifstream spreadsheet_file(full_filename);

	if (!spreadsheet_file.is_open())
	{
		spreadsheet::change _change = spreadsheet::change();
		// We have a new file
		spreadsheet::spreadsheet* new_spreadsheet = new spreadsheet::spreadsheet(_change);
		return new_spreadsheet;
	}

	std::string line;

	getline(spreadsheet_file, line);

	if (line != "undo")
		throw "File not in correct format. (Missing undos)";

	// Handle undos
	spreadsheet::undo undo_stack;
	while (getline(spreadsheet_file, line) && line != "revert")
	{

		std::string name = line.substr(0, line.find(","));
		std::string contents = line.substr(line.find(",") + 1);

		std::cout << name << " " << contents << std::endl;

		undo_stack.push(name, contents);
	}

	if (line != "revert")
		throw "File not in correct format. (Missing reverts)";

	// Handle reverts
	std::map<std::string, spreadsheet::revert> revert_map;
	while (getline(spreadsheet_file, line))
	{

		spreadsheet::revert* reverts = new spreadsheet::revert();

		std::vector<std::string> items;

		// Credit for the following Regex Help - https://stackoverflow.com/questions/61624907/how-to-choose-when-to-split-a-string-with-comma
		std::regex comma_reg(",", std::regex_constants::ECMAScript | std::regex_constants::icase);
		std::copy(std::sregex_token_iterator(line.begin(), line.end(), comma_reg, -1),
			std::sregex_token_iterator(),
			std::back_inserter(items));

		std::string name = items[0];

		items.erase(items.begin());

		for (std::string item : items)
		{
			reverts->push(item);
		}

		std::pair<std::string, spreadsheet::revert> name_reverts_pair(name, *(reverts));

		revert_map.insert(name_reverts_pair);
	}

	spreadsheet_file.close();

	spreadsheet::change spreadsheet_builder = spreadsheet::change(undo_stack, revert_map);

	spreadsheet::spreadsheet* open_spreadsheet = new spreadsheet::spreadsheet(spreadsheet_builder);

	return open_spreadsheet;
}

void write_file(std::string filename, spreadsheet::spreadsheet* modified_spreadsheet)
{
	std::string full_filename = SPREADSHEET_PATH + filename;

	std::ofstream spreadsheet_file(full_filename);

	spreadsheet::change spreadsheet_builder = modified_spreadsheet->getchange();

	if (!spreadsheet_file.is_open())
	{
		std::string error_str = "Couldn't write file: " + filename;
		throw error_str;
	}

	spreadsheet_file << "undo" << std::endl;

	spreadsheet::undo undo_stack = spreadsheet_builder.getUndomap();

	spreadsheet::undo undo_stack_rev;

	size_t undo_size = undo_stack.getsize();

	for (int i = 0; i < undo_size; i++)
	{
		spreadsheet::twostrings undo_item = undo_stack.pop();
		undo_stack_rev.push(undo_item.getcellname(), undo_item.getcellcontents());
	}

	for (int i = 0; i < undo_stack_rev.getsize(); i++)
	{
		spreadsheet::twostrings undo_item = undo_stack_rev.pop();
		spreadsheet_file << undo_item.getcellname() << "," << undo_item.getcellcontents() << std::endl;
		undo_stack.push(undo_item.getcellname(), undo_item.getcellcontents());
	}

	spreadsheet_file << "revert" << std::endl;

	std::map<std::string, spreadsheet::revert> revert_stacks = spreadsheet_builder.getmap();

	for (std::pair<std::string, spreadsheet::revert> revert_stack : revert_stacks)
	{

		spreadsheet_file << revert_stack.first << ",";
		spreadsheet::revert states = revert_stack.second;

		size_t states_size = states.getsize(); // Get this size BEFORE the loop that takes values out, lol

		for (int j = 0; j < states_size; j++)
		{
			states.push(states.pop().getcellcontents());
		}

		for (int j = 0; j < states_size; j++)
		{
			std::string value = states.pop().getcellcontents();
			spreadsheet_file << value << ",";
			states.push(value); // Rebuild the original stack
		}

		spreadsheet_file << std::endl;
	}

	spreadsheet_file.close();
}

void client_open_spreadsheet(int client_id, std::string filename)
{
	spreadsheet::spreadsheet* opened_sheet;


	if (clients_using_spreadsheet.at(filename).size() > 0)
	{
		info_by_client_id.at(clients_using_spreadsheet.at(filename)[0]).open_spreadsheet;
		opened_sheet = info_by_client_id.at(clients_using_spreadsheet.at(filename)[0]).open_spreadsheet;
		clients_using_spreadsheet.at(filename).push_back(client_id);
	}
	else
	{
		opened_sheet = open_spreadsheet_file(filename);
		vector<int> client_ids{ client_id };
		clients_using_spreadsheet.at(filename).push_back(client_id);
	}

	vector<int> client_ids{ client_id };
	// Pair filename with list of client IDs
	std::pair<std::string, std::vector<int>> pair;
	pair.first = filename;
	pair.second = std::vector<int>(client_ids);
	clients_using_spreadsheet.insert(pair);


	info_by_client_id.at(client_id).filename = filename;
	info_by_client_id.at(client_id).open_spreadsheet = opened_sheet;

	// We need to send the values at the top of these stacks
	map<std::string, spreadsheet::revert> revert_map = opened_sheet->getchange().getmap();

	// Send all of the current cell values
	for (std::pair<std::string, spreadsheet::revert> revert_stack : revert_map)
	{
		std::string cell_name = revert_stack.first;
		std::string cell_contents = revert_stack.second.getTop().getcellcontents();

		std::string messageType = "cellUpdated";
		std::string message = encode(messageType, cell_name, cell_contents, "", client_id);

		info_by_client_id.at(client_id).state->send(message);
	}

	// Send all of the cell selections
	std::vector<int> spreadsheet_user_ids = clients_using_spreadsheet.at(filename);

	for (int spreadsheet_user_id : spreadsheet_user_ids)
	{
		std::string selection = info_by_client_id.at(spreadsheet_user_id).cell_selected;
		if (selection != "")
		{
			info_by_client_id.at(spreadsheet_user_id).state->send(selection); // TODO MASSAGE
		}
	}

	// Complete the handshake
	std::string client_id_newline = to_string(client_id) + "\n";
	info_by_client_id.at(client_id).state->send(client_id_newline); // TODO was MEHYASSAGE MESSGE
}

void client_select_cell(int client_id, std::string cell_name)
{
	info_by_client_id.at(client_id).cell_selected = cell_name;

	std::string messageType = "cellSelected";
	std::string message = encode(messageType, cell_name, "", "", client_id);

	std::string filename = info_by_client_id.at(client_id).filename;
	std::vector<int> spreadsheet_users = clients_using_spreadsheet.at(filename);

	for (int i = 0; i < spreadsheet_users.size(); i++)
	{
		client_id = spreadsheet_users.at(i);
		info_by_client_id.at(client_id).state->send(message);
	}
}

void client_edit_cell(int client_id, std::string cell_name, std::string cell_contents)
{
	if (info_by_client_id.at(client_id).cell_selected != cell_name)
	{
		return;
	}

	spreadsheet::spreadsheet* modified_spreadsheet = info_by_client_id.at(client_id).open_spreadsheet;

	if (!modified_spreadsheet->push(cell_name, cell_contents))
	{
		std::string messageType = "requestError";
		std::string errorMessage = "Invalid_cell_contents";
		std::string message = encode(messageType, cell_name, "", errorMessage);
		info_by_client_id.at(client_id).state->send(message);
		return;
	}

	std::string messageType = "cellUpdated";

	std::string message = encode(messageType, cell_name, cell_contents, "", client_id);

	std::string filename = info_by_client_id.at(client_id).filename;
	std::vector<int> spreadsheet_users = clients_using_spreadsheet.at(filename);
	for (int i = 0; i < spreadsheet_users.size(); i++)
	{
		client_id = spreadsheet_users.at(i);
		info_by_client_id.at(client_id).state->send(message);
	}

	write_file(filename, modified_spreadsheet);
}

void client_revert(int client_id, std::string cell_name)
{
	spreadsheet::spreadsheet* modified_spreadsheet = info_by_client_id.at(client_id).open_spreadsheet;

	std::string previous_value = modified_spreadsheet->revert(cell_name).getcellcontents();
	std::string new_name = modified_spreadsheet->revert(cell_name).getcellname();


	// Shouldn't need this anymore, but code his here just in case
	//if (previous_value == "") {
	//std::string message = encode("Invalid request", cell_name, NULL, "No more reverts available for this cell"); // TODO Not sure what the exact message is
	//// TODO: Send requesting client error message
	//return;
	//}

	std::string messageType = "cellUpdated";
	std::string message = encode(messageType, cell_name, previous_value, "", client_id);

	std::string filename = info_by_client_id.at(client_id).filename;
	std::vector<int> spreadsheet_users = clients_using_spreadsheet.at(filename);

	for (int i = 0; i < spreadsheet_users.size(); i++)
	{
		client_id = spreadsheet_users.at(i);
		info_by_client_id.at(client_id).state->send(message);
	}
	write_file(filename, modified_spreadsheet);
}

void client_undo(int client_id)
{

	spreadsheet::spreadsheet* modified_spreadsheet = info_by_client_id.at(client_id).open_spreadsheet;

	spreadsheet::twostrings reverse_change = modified_spreadsheet->undo();

	if (reverse_change.getcellname() == "")
	{
		std::string messageType = "requestError";
		std::string errorMessage = "No more undos available";
		//std::string message = encode(messageType, "", "", errorMessage, client_id);
		//info_by_client_id.at(client_id).state->send(message);
		return;
	}

	std::string messageType = "cellUpdated";
	std::string message = encode(messageType, reverse_change.getcellname(), reverse_change.getcellcontents(), "", client_id);

	std::string filename = info_by_client_id.at(client_id).filename;
	std::vector<int> spreadsheet_users = clients_using_spreadsheet.at(filename);
	for (int i = 0; i < spreadsheet_users.size(); i++)
	{
		client_id = spreadsheet_users.at(i);
		info_by_client_id.at(client_id).state->send(message);
	}

	write_file(filename, modified_spreadsheet);
}

void client_close_spreadsheet(int client_id)
{
	std::string filename = info_by_client_id.at(client_id).filename;
	spreadsheet::spreadsheet* closed_spreadsheet = info_by_client_id.at(client_id).open_spreadsheet;
	info_by_client_id.erase(client_id);

	std::vector<int> clients = clients_using_spreadsheet.at(filename);
	std::vector<int>::iterator it = std::find(clients.begin(), clients.end(), client_id);

	clients.erase(it);

	std::string messageType = "disconnected";
	std::string message = encode(messageType, "", "", "", client_id);

	for (int i = 0; i < clients.size(); i++)
	{
		client_id = clients.at(i);
		info_by_client_id.at(client_id).state->send(message);
	}

	// No users left using the spreadsheet
	if (clients.size() == 0)
	{
		clients_using_spreadsheet.erase(filename);
		delete (closed_spreadsheet);
	}
}

std::string encode(std::string messageType, std::string cellName, std::string cellContents, std::string message, int user)
{
	Json::Value root;

	root["messageType"] = messageType;

	if (cellName != "" && messageType != "cellSelected") {
		root["contents"] = cellContents;
		root["cellName"] = cellName;
	}
	else if (cellName != "") {
		root["cellName"] = cellName;
	}
	if (message != "")
		root["message"] = message;

	if (user != -1)
	{
		if (messageType == "cellSelected")
		{
			root["selector"] = user;
			root["selectorName"] = info_by_client_id.at(user).username;
		}
		else if (messageType == "disconnected")
		{
			// Disconnected
			root["user"] = user;
		}
	}

	Json::StreamWriterBuilder builder;
	std::string json_msg = Json::writeString(builder, root);
	json_msg.erase(std::remove_if(json_msg.begin(), json_msg.end(), ::isspace), json_msg.end());

	json_msg += "\n";

	return json_msg;
}

void decode_and_handle(int client_id, std::string message)
{
	Json::Value root;

	std::stringstream(message) >> root;

	std::string requestType = root.get("requestType", "=NULL").asString();
	std::string cellName = root.get("cellName", "=NULL").asString();
	std::string contents = root.get("contents", "=NULL").asString();

	if (requestType == "editCell")
	{
		if (cellName == "=NULL" || contents == "=NULL")
		{
			send_bad_request(client_id);
		}
		client_edit_cell(client_id, cellName, contents);
	}
	else if (requestType == "revertCell")
	{
		if (cellName == "=NULL")
		{
			send_bad_request(client_id);
		}
		client_revert(client_id, cellName);
	}
	else if (requestType == "selectCell")
	{
		if (cellName == "=NULL")
		{
			send_bad_request(client_id);
		}
		client_select_cell(client_id, cellName);
	}
	else if (requestType == "undo")
	{
		client_undo(client_id);
	}
	else
	{
		send_bad_request(client_id);
	}
}

void send_bad_request(int client_id)
{
	std::string messageType = "requestError";
	std::string errorMessage = "Insufficient JSON data.";
	std::string message = encode("requestError", "", "", errorMessage, client_id);
	info_by_client_id.at(client_id).state->send(message);
}

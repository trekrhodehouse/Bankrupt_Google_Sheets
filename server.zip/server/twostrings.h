#pragma once
#ifndef TWOSTRINGS_H
#define TWOSTRINGS_H
#include <string>
namespace spreadsheet
{
    class twostrings {
        std::string cellname;
        std::string cellcontents;
    public:
        twostrings(std::string  string1, std::string string2);

        std::string getcellname();
        std::string getcellcontents();

    };


}
#endif

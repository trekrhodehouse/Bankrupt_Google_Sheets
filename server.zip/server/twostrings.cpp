
#include "twostrings.h"

namespace spreadsheet {
    spreadsheet::twostrings::twostrings(std::string string1, std::string  string2) {
        cellname = string1;
        cellcontents = string2;
    }

    // Note from Corey, may want to change this to contents - value is the value calculated by client
    std::string twostrings::getcellcontents() {
        return cellcontents;
    }
    std::string twostrings::getcellname() {
        return cellname;
    }
}

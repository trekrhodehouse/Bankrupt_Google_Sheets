/*
 *
 *cpp file to make undo and revert work together
 */

#include "change.h"
namespace spreadsheet
{
    undo change::getUndomap()
    {
        return undomap;
    }
    map<std::string, spreadsheet::revert> change::getmap()
    {
        return themap;
    }
    change::change()
    {
        themap =  map<string, revert>();
        undomap =  undo();
        Circ =  DependencyGraph();
    }

    change::change(undo _undomap, map<string, revert> _themap) : undomap(_undomap), themap(_themap) 
    {
        Circ = DependencyGraph();

        for (std::map<std::string, revert>::iterator list = themap.begin(); list != themap.end(); list++) 
        {

            revert value = list->second;
            if (!ChangeDependencies(value.getcellname(), value.getTop().getcellcontents()))
            {
                throw 1;
            }

          
        }
    }
    /*
    this push checks if the map has the revert stack already in it if it does not then it adds it to the map then it after that it checks what the top of the revert stack is 
    */
    bool change::push(std::string cellname, std::string cellvalue)
    {
        if (ChangeDependencies(cellname, cellvalue)) {


            if (themap.count(cellname) < 1)
            {
                revert name = revert(cellname);
                themap.insert(std::pair<std::string, revert>(cellname, name));
            }
            twostrings cell = themap.at(cellname).getTop();
            themap.at(cellname).push(cellvalue);

            undomap.push(cell.getcellname(), cell.getcellcontents());

            return true;
        }
        return false;
    }

    
    /*
    this method attempts to undo the last change if their is not a last change as in the undomap is empty it does not affect the revert map and 
    returns an empty string name and contents in the twostrings object
    */
    twostrings change::Undodata()
    {
        twostrings cell = undomap.pop();
    
        if (cell.getcellname() == "") 
        {
            return cell;
        }
     //   changeDependencies(cell);
        ChangeDependencies(cell.getcellname(), cell.getcellcontents());
        themap.at(cell.getcellname()).push(cell.getcellcontents());
        return cell;


    }

    /*
    this method returns the current data in a specific cellname as a two string with the cellname then the cell contents 
    if the revert stack is empty or has not been put into the map at alll it returns a twostring object with an empty cellname and cell contents to alert the user. 
    */
    twostrings change::Revertdata(std::string _cellname)
    {


        //need to add a way to check for circular dependencies and change the value of the dependency graph
     
        if (themap.count(_cellname)>=1)
        {
            twostrings cell = themap.at(_cellname).pop();
            twostrings cell2 = themap.at(_cellname).getTop();
            if (cell.getcellname() == "") 
            {
                return cell;
            }
        //    if (CheckCircularDependencies(cell)) {
        //        twostrings error = twostrings("CIRCULAR DEPENDENCY", cell.getcellcontents);
        //       return error;
        //   }
            if (ChangeDependencies(_cellname, cell2.getcellcontents())) {
                undomap.push(_cellname, cell.getcellcontents());
                return cell2;
            }
            else {
                twostrings circular = twostrings("CIRCULAR DEPENDENCY", cell.getcellcontents());
                return circular;
            }
        }
        else {
            twostrings empty = twostrings("", "");
            return empty;
        }


    }
    /*
    returns true if there are no Circular Dependencies
    */
    bool change::CheckCircularDependencies(std::string start,std::string current, vector<std::string> visited, std::string contents) 
    {
        std::vector<std::string> variables;
        if(start == current){
            SpreadsheetUtilities::Formula DaFormula = SpreadsheetUtilities::Formula(contents);
                variables = DaFormula.GetVariables();
        }
        else {
            variables = Circ.GetDependents(current);
            visited.push_back(current);
        }
            
            // adds the first name into the visisted list
           
            for (int i = 0; i < variables.size(); i++)
            {
                bool visit = false;
                for (int j = 0; j < visited.size(); j++) {
                    if (variables[i] == visited[j]) {
                        visit = true;
                    }
                }
                if (visit) {

                }
                else {


                    if (variables[i] == start)
                    {
                        // throws if any dependent is the original and making a cycle
                        return false;
                    }

                    for (int i = 0; i < variables.size(); i++)
                    {

                        // goes through the direct dependents of each dependent and then makes sure that 
                        //none of its dependents contain the Starting string

                        if (!CheckCircularDependencies(start, variables[i], visited, contents))
                        {
                            return false;
                        }
                    }
                }
            }
            return true;
           
        
    }
   
    bool change::ChangeDependencies(std::string cellname, std::string cellcontents) 
    {
        if (cellcontents.substr(0, 1) == "=") 
        {

            SpreadsheetUtilities::Formula contents =  SpreadsheetUtilities::Formula(cellcontents.substr(1, cellcontents.length() - 1));//this might need to be -2
            std::vector<std::string> emptyvector =  std::vector<std::string>();

            if (CheckCircularDependencies(cellname,cellname,emptyvector, cellcontents)) 
            {
                
          
                std::vector<std::string> variables = contents.GetVariables();
                
                if (Circ.DependentContainsKey(cellname)) 
                {
                    Circ.ReplaceDependees(cellname, contents.GetVariables());
                   
                }
                else 
                {
                    for (int i = 0; i < variables.size(); i++) 
                    {

                        Circ.AddDependency(cellname, variables[i]);
                    }
                }
             
            }
            else
            {
                return false;
            }
        }
        else
        {
            std::vector<std::string> dependees = Circ.GetDependees(cellname);
            for (int i = 0; i < dependees.size(); i++) 
            {
                Circ.RemoveDependency(cellname, dependees[i]);

            }
            
        }
        return true;
    }

}


#pragma once

#include "change.h"
#include "twostrings.h"
#include "Formula_Evaluator.h"
 
namespace spreadsheet {

	class spreadsheet {
		bool validate();
		change changeobject;
	public:
		spreadsheet(change changeobject);
		change getchange();
		twostrings revert(std::string stringname);
		bool push(std::string cellname, std::string cellvalue);
	
		twostrings undo();
	};

}
#pragma once
#ifndef UNDO_H
#define UNDO_H

#include <stack>
#include <string>
#include "twostrings.h"
namespace spreadsheet
{
    class undo {
        std::stack<twostrings> values;

    public:
        int size;
        int getsize();
        ~undo();
        undo();
        twostrings pop();

        void push(std::string cellname, std::string newvalue);
    };


}
#endif
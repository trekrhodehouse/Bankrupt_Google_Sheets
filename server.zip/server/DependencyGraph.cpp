#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <iterator>     
#include "DependencyGraph.h"
   

/// <summary>
/// 
/// </summary>
DependencyGraph::DependencyGraph()
{

    Dependents = new std::map<std::string, std::vector<std::string>>();
    Dependees = new std::map<std::string, std::vector<std::string>>();
    size = 0;
}
/// <summary>
/// 
/// </summary>
/// <returns></returns>
int DependencyGraph::Size()
{
    return Dependents->size();
}
/// <summary>
/// 
/// </summary>
/// <param name="s"></param>
/// <returns></returns>
bool DependencyGraph::HasDependees(std::string s)
{
    return DependeeContainsKey(s);
}
/// <summary>
/// 
/// </summary>
/// <param name="s"></param>
/// <returns></returns>
bool DependencyGraph::HasDependents(std::string s)
{
    return DependentContainsKey(s);
}
/// <summary>
/// 
/// </summary>
/// <param name="s"></param>
/// <returns></returns>
std::vector<std::string> DependencyGraph::GetDependents(std::string s)
{   
    std::vector<std::string>value;
    for (std::map<std::string, std::vector<std::string>>::iterator list = Dependents->begin(); list != Dependents->end(); list++) {
        if (list->first == s) {         
            value = list->second;
        }
    }
    return value;
}
/// <summary>
/// 
/// </summary>
/// <param name="s"></param>
/// <returns></returns>
std::vector<std::string> DependencyGraph::GetDependees(std::string s)
{ 
    std::vector<std::string>value;
    for (std::map<std::string, std::vector<std::string>>::iterator list = Dependees->begin(); list != Dependees->end(); list++) {
        if (list->first == s) {           
            value = list->second;
        }
    }
    return value;
}
/// <summary>
/// 
/// </summary>
/// <param name="s"></param>
/// <param name="t"></param>
void DependencyGraph::AddDependency(std::string s, std::string t)
{
    std::vector<std::string>dependentValue;
    std::vector<std::string>dependeeValue;
    if (DependentContainsKey(s)) {
        if (DependeeContainsKey(t)) {
            for (std::map<std::string, std::vector<std::string>>::iterator list = Dependents->begin(); list != Dependents->end(); list++) {
                if (list->first == s) {
                    dependentValue = list->second;
                    dependentValue.push_back(t);
                    Dependents->at(s) = dependentValue;
                }
            }
            for (std::map<std::string, std::vector<std::string>>::iterator list = Dependees->begin(); list != Dependees->end(); list++) {
                if (list->first == t) {
                    dependeeValue = list->second;
                    dependeeValue.push_back(s);
                    Dependees->at(t) = dependeeValue;
                }
            }
        }
        else {
            for (std::map<std::string, std::vector<std::string>>::iterator list = Dependents->begin(); list != Dependents->end(); list++) {
                if (list->first == s) {
                    dependentValue = list->second;
                    dependentValue.push_back(t);
                    Dependents->at(s) = dependentValue;
                }
            }
            dependeeValue.push_back(s);
            Dependees->insert(std::pair<std::string, std::vector<std::string>>(t, dependeeValue));
        }
    }
    else {
        if (DependeeContainsKey(t)) {
            for (std::map<std::string, std::vector<std::string>>::iterator list = Dependees->begin(); list != Dependees->end(); list++) {
                if (list->first == t) {
                    dependeeValue = list->second;
                    dependeeValue.push_back(s);
                    Dependees->at(t) = dependeeValue;
                }
            }
            dependentValue.push_back(t);
            Dependents->insert(std::pair<std::string, std::vector<std::string>>(s, dependentValue));
        }
        else {
            dependentValue.push_back(t);
            Dependents->insert(std::pair<std::string, std::vector<std::string>>(s, dependentValue));
            dependeeValue.push_back(s);
            Dependees->insert(std::pair<std::string, std::vector<std::string>>(t, dependeeValue));
        }
    }    
}
/// <summary>
/// 
/// </summary>
/// <param name="s"></param>
/// <param name="t"></param>
void DependencyGraph::RemoveDependency(std::string s, std::string t)
{
    std::vector<std::string>dependentValue;
    std::vector<std::string>dependeeValue;
    std::vector<std::string>value;
  
    if (DependentContainsKey(s)&&DependeeContainsKey(t)) {
        for (std::map<std::string, std::vector<std::string>>::iterator list = Dependents->begin(); list != Dependents->end(); list++) {
            if (list->first == s) {
                value = list->second;
                for (int i = 0; i < value.size(); i++) {
                    if (value.at(i) == t) {
                        value.erase(value.begin()+i);
                    }
               }
                Dependents->at(s) = value;
            }
        }
        for (std::map<std::string, std::vector<std::string>>::iterator list = Dependees->begin(); list != Dependees->end(); list++) {
            if (list->first == t) {
                value = list->second;
                for (int i = 0; i < value.size(); i++) {
                    if (value.at(i) == s) {
                        value.erase(value.begin() + i);
                    }
                }
                Dependees->at(t) = value;
            }
        }
    }
    
}
/// <summary>
/// 
/// </summary>
/// <param name="s"></param>
/// <returns></returns>
bool DependencyGraph::DependeeContainsKey(std::string s)
{
    std::vector<std::string>value;
    std::map<std::string, std::vector<std::string>>::iterator list = Dependees->find(s);
    if (list != Dependees->end()) {
        for (std::map<std::string, std::vector<std::string>>::iterator list = Dependees->begin(); list != Dependees->end(); list++) {
            if (list->first == s) {
                value = list->second;
                return true;
            }
        }
    }
   
    return false;
}
/// <summary>
/// 
/// </summary>
/// <param name="s"></param>
/// <returns></returns>
bool DependencyGraph::DependentContainsKey(std::string s)
{
    std::vector<std::string>value;
    std::map<std::string, std::vector<std::string>>::iterator list = Dependents->find(s);
    if (list != Dependents->end()) {
        for (std::map<std::string, std::vector<std::string>>::iterator list = Dependents->begin(); list != Dependents->end(); list++) {
            if (list->first == s) {
                value = list->second;
                return true;
            }
        }
    }
    return false;
}
/// <summary>
/// 
/// </summary>
/// <param name="s"></param>
/// <param name="newDependents"></param>
void DependencyGraph::ReplaceDependents(std::string s,std::vector<std::string> newDependents)
{ 
   
    std::vector<std::string>value = GetDependents(s);
    for (int i = 0; i < value.size(); i++) {
        RemoveDependency(s, value.at(i));
    }
    for (int i = 0; i < newDependents.size(); i++) {
        AddDependency(s, newDependents.at(i));
    }
    
}
/// <summary>
/// 
/// </summary>
/// <param name="s"></param>
/// <param name="newDependees"></param>
void DependencyGraph::ReplaceDependees(std::string s, std::vector <std::string> newDependees)
{
    std::vector<std::string>value = GetDependees(s);
    for (int i = 0; i < value.size(); i++) {
        RemoveDependency(s, value.at(i));
    }
    for (int i = 0; i < newDependees.size(); i++) {
        AddDependency(s, newDependees.at(i));
    }
}
/// <summary>
/// 
/// </summary>
void DependencyGraph::printDependents() {
    std::vector<std::string>value;
    for (std::map<std::string, std::vector<std::string>>::iterator list = Dependents->begin(); list != Dependents->end(); list++) {                    
        value = list->second;
        for (int i = 0; i < value.size(); i++) {
            std::cout << "Key: " << list->first << " = " <<  "value at " << i << " = " << value.at(i) << std::endl;
        }        
    }
}
/// <summary>
/// 
/// </summary>
void DependencyGraph::printDependees() {
    std::vector<std::string>value;
    for (std::map<std::string, std::vector<std::string>>::iterator list = Dependees->begin(); list != Dependees->end(); list++) {
        value = list->second;
        for (int i = 0; i < value.size(); i++) {
            std::cout << "Key: " << list->first << " = " << "value at " << i <<  " = " << value.at(i) << std::endl;
        }
    }
}



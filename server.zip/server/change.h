#pragma once

/*
 *this class encompasses the interaction between undo and revert
 */


#ifndef CHANGE_H
#define CHANGE_H
#include <map>
#include <string>
#include "Undo.h"
#include "Revert.h"
#include "twostrings.h"
#include "DependencyGraph.h"
#include "Formula_Evaluator.h"

using namespace std;
namespace spreadsheet
{
    class change {
        map<string, revert>  themap;
        undo undomap;
        DependencyGraph Circ;
    public:
        bool ChangeDependencies(std::string cellname, std::string cellcontents);
        bool CheckCircularDependencies(std::string start, std::string current, vector<std::string> visited, std::string contents);
        undo getUndomap();
        map<string, revert> getmap();
        change();
        change(undo _undomap, map<string, revert> _themap);
        bool push(std::string cellname, std::string cellvalue);
        twostrings Undodata();
        twostrings Revertdata(string cellname);
    };


}
#endif

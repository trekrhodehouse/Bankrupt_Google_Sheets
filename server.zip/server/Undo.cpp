#include "Undo.h"
namespace spreadsheet
{
    spreadsheet::undo::undo()
    {
        values = std::stack<twostrings>();
        size = 0;
    }


    spreadsheet::undo::~undo()
    {

    }
    /*
    this returns the value that is the current top of the stack if the stack is completely empty it returns a twostrings object with a empty cellname
    */
    int undo::getsize() {

        return size;
    }
    twostrings undo::pop() {
        size--;
        if (!values.empty()) {
            twostrings value = values.top();
            values.pop();


            return value;
        }
        else {
            twostrings empty = twostrings("", "");
            return empty;
        }

    }

    void undo::push(std::string cellname, std::string celldata) {
        size++;
        twostrings data = twostrings(cellname, celldata);
        values.push(data);
    }

}

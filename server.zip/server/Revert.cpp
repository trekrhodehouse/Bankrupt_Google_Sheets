//tempfile
#include "Revert.h"
namespace spreadsheet {
    spreadsheet::revert::revert(std::string _cellname) {
        size = 0;
        cellname = _cellname;
        values = std::stack<std::string>();
    }
    spreadsheet::revert::revert() {
        size = 0;
        cellname = "Default";
        values = std::stack<std::string>();
    }


    spreadsheet::revert::~revert() {

    }
    void revert::setcellname(std::string _cellname) {
        cellname = _cellname;
    }

    std::string revert::getcellname()
    {
        return cellname;
    }
    /*
    this code gives you the value that is currently on top of the stack.
    */
    int revert::getsize() {
        return size;
    }
    twostrings revert::getTop() {

        if (values.empty()) {
            twostrings empty = twostrings(cellname, "");
            return empty;
        }
        else {
            twostrings value = twostrings(cellname, values.top());
            return value;
        }
    }

    /*
    this gives the value that was previously on top of the stack
    */
    twostrings revert::pop() { // a7 a5
        size--;
        if (!values.empty()) {


            twostrings value = twostrings(cellname, values.top());
            values.pop();

            return value;
        }
        else {
            twostrings empty = twostrings("", "");
            return empty;
        }

    }

    void revert::push(std::string data) {
        size++;
        values.push(data);
    }

}

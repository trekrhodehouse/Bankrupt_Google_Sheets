// Skeleton written by Joe Zachary for CS 3500, September 2013
// Read the entire skeleton carefully and completely before you
// do anything else!

// Version 1.1 (9/22/13 11:45 a.m.)

// Change log:
//  (Version 1.1) Repaired mistake in GetTokens
//  (Version 1.1) Changed specification of second constructor to
//                clarify description of how validation works

// (Daniel Kopta)
// Version 1.2 (9/10/17)

// Change log:
//  (Version 1.2) Changed the definition of equality with regards
//                to numeric tokens

//Works cited, https://www.techiedelight.com/convert-string-vector-chars-cpp/ for the beginning of the Formula constructor.

#include "Formula_Evaluator.h"
#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>
#include <sstream>
#include <stack>
namespace SpreadsheetUtilities
{
    /// <summary>
    /// Represents formulas written in standard infix notation using standard precedence
    /// rules.  The allowed symbols are non-negative numbers written using double-precision
    /// floating-point syntax (without unary preceeding '-' or '+');
    /// variables that consist of a letter or underscore followed by
    /// zero or more letters, underscores, or digits; parentheses; and the four operator
    /// symbols +, -, *, and /.
    ///
    /// Spaces are significant only insofar that they delimit tokens.  For example, "xy" is
    /// a single variable, "x y" consists of two variables "x" and y; "x23" is a single variable;
    /// and "x 23" consists of a variable "x" and a number "23".
    ///
    /// Associated with every formula are two delegates:  a normalizer and a validator.  The
    /// normalizer is used to convert variables into a canonical form, and the validator is used
    /// to add extra restrictions on the validity of a variable (beyond the standard requirement
    /// that it consist of a letter or underscore followed by zero or more letters, underscores,
    /// or digits.)  Their use is described in detail in the constructor and method comments.
    /// </summary>

    
        //the array that stores the tokens of the formula for future use

        /// <summary>
        /// Creates a Formula from a string that consists of an infix expression written as
        /// described in the class comment.  If the expression is syntactically invalid,
        /// throws a FormulaFormatException with an explanatory Message.
        ///
        /// The associated normalizer is the identity function, and the associated validator
        /// maps every string to true.
        /// </summary>

        /// <summary>
        /// Creates a Formula from a string that consists of an infix expression written as
        /// described in the class comment.  If the expression is syntactically incorrect,
        /// throws a FormulaFormatException with an explanatory Message.
        ///
        /// The associated normalizer and validator are the second and third parameters,
        /// respectively.
        ///
        /// If the formula contains a variable v such that normalize(v) is not a legal variable,
        /// throws a FormulaFormatException with an explanatory message.
        ///
        /// If the formula contains a variable v such that isValid(normalize(v)) is false,
        /// throws a FormulaFormatException with an explanatory message.
        ///
        /// Suppose that N is a method that converts all the letters in a string to upper case, and
        /// that V is a method that returns true only if a string consists of one letter followed
        /// by one digit.  Then:
        ///
        /// new Formula("x2+y3", N, V) should succeed
        /// new Formula("x+y3", N, V) should throw an exception, since V(N("x")) is false
        /// new Formula("2x+y3", N, V) should throw an exception, since "2x+y3" is syntactically incorrect.
        /// </summary>
        Formula::Formula(std::string formula)
        {
            variableStorer = std::vector<std::string>();
            TokenStorer = GetTokens(formula);
            int NumberOfRP = 0;
            int NumberOfLP = 0;
            std::string CurrentString = "";
            std::string NextString = "";
            if (TokenStorer.size() == 0)
            {
                //Create new throw message for all of these.
                //throw new FormulaFormatException("A formula needs at least one token, please try adding at least one token");
            }
            for (int i = 0; i < TokenStorer.size(); i++)
            {

                if (NumberOfLP > NumberOfRP)
                {
                    throw 1; 
                }
                CurrentString.assign(TokenStorer[i]);

                if (is_numeric(CurrentString) || IsAnOperator(CurrentString) || CurrentString == "(" || CurrentString == ")")
                {
                    if (CurrentString == "(")
                    {
                        NumberOfRP++;
                    }
                    if (CurrentString == ")")
                    {
                        NumberOfLP++;
                    }
                }

                else
                {
                    if (IsAVariable(CurrentString))
                    {
                        TokenStorer[i] = Normalize(CurrentString);
                    }
                }

                if (i < TokenStorer.size() - 1)
                {
                    NextString.assign(TokenStorer[i + 1]);
                }

                if (i == 0 && CurrentString != "(" && !is_numeric(CurrentString) && !IsAValidVariable(CurrentString))
                {
                    throw 1; 
                }
                if (i == TokenStorer.size() - 1 && CurrentString != ")" && !is_numeric(CurrentString) && !IsAValidVariable(CurrentString))
                {
                    throw 1; 
                }
                if (CurrentString == "(" || IsAnOperator(CurrentString))
                {
                    if (i < TokenStorer.size() - 1){
                    if (NextString != "(" && !is_numeric(NextString) && !IsAValidVariable(NextString))
                    {
                    throw 1; 
                    }}
                }
                if (CurrentString == ")" || is_numeric(CurrentString) || IsAValidVariable(CurrentString))
                {
                    if (i < TokenStorer.size() - 1){
                    if (NextString != ")" && NextString != "" && !IsAnOperator(NextString))
                    {
                    throw 1; 
                    }}
                }
            }
            if (NumberOfLP != NumberOfRP)
            {
                    throw 1; 
            }
        }
        
        ///TODO FIX THIS
        bool Formula::IsValid(std::string variable)
        {
            return true;
        }

        std::string Formula::Normalize(std::string variable)
        {
            return variable;
        }


        /// <summary>
        /// takes a string of code and determines if it is a variable after normalizing and validating
        /// </summary>
        /// <param name="s"></param>
        /// <param name="normalize"></param>
        /// <param name="isValid"></param>
        /// <returns></returns>

        bool Formula::IsAVariable(std::string s)
        {

            if (IsAValidVariable(s))
            {
                try
                {
                    IsAValidVariable(Normalize(s));
                }
                catch (int e)
                {
                    throw 1; 
                }
                if (IsValid(Normalize(s)))
                {

                    return true;
                }
                else
                {
                    throw 1; 
                }
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// a simpler method that checks if the token input is a valid variable. this is used when you have already checked the validator and stored
        /// it in the token storage does not revalidate in order to simplify and for methods that don't have access to the validator.
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>

        bool Formula::IsAValidVariable(std::string s)
        {
            if (s.size() <= 1){
                return false;
            }
            if (is_numeric(s) || IsAnOperator(s) || s == "(" || s == ")")
            {
                return false;
            }
            if (!std::isalpha(s.at(0)))
                {
                    return false;
                }

            std::string NumberPortion = s.substr(1, s.size()-1);
            if (is_numeric(NumberPortion))
            {
                return true;
            }
            else
            {
                    throw 1; 
            }
        }
        /// <summary>
        /// this is a check if the token passed is an operator used when checking the next string and or current string
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>

        bool Formula::IsAnOperator(std::string s)
        {
            if (s == "*" || s == "/" || s == "+" || s == "-")
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Evaluates this Formula, using the lookup delegate to determine the values of
        /// variables.  When a variable symbol v needs to be determined, it should be looked up
        /// via lookup(normalize(v)). (Here, normalize is the normalizer that was passed to
        /// the constructor.)
        ///
        /// For example, if L("x") is 2, L("X") is 4, and N is a method that converts all the letters
        /// in a string to upper case:
        ///
        /// new Formula("x+7", N, s => true).Evaluate(L) is 11
        /// new Formula("x+7").Evaluate(L) is 9
        ///
        /// Given a variable symbol as its parameter, lookup returns the variable's value
        /// (if it has one) or throws an ArgumentException (otherwise).
        ///
        /// If no undefined variables or divisions by zero are encountered when evaluating
        /// this Formula, the value is returned.  Otherwise, a FormulaError is returned.
        /// The Reason property of the FormulaError should have a meaningful explanation.
        ///
        /// This method should never throw an exception.
        /// </summary>

        //FIXED FOR NOW
        //MUST FIX EXCEPTIONS, LOOKUP AND VARIABLE CHECKER
        int Formula::Evaluate()
        {
            std::stack<std::string> OperatorStack;
            std::stack<double> ValueStack;

            std::string CurrentToken;
            double NewInt;
            std::string t;
            double operationhelp;
            //goes through all tokens to evaluate
            for (int i = 0; i < TokenStorer.size(); i++)
            {
                CurrentToken.assign(TokenStorer[i]);
                // dismisses any empty strings.
                if (CurrentToken=="")
                {
                    continue;
                }
                // determins if the token is one of the three that only needs to be pushed into the stack,
                if (CurrentToken=="(" || CurrentToken=="*" || CurrentToken=="/")
                {

                    OperatorStack.push(CurrentToken);
                    continue;
                }
                // proccesses when the next token is an )
                else if (CurrentToken==")")
                {

                    t.assign(OperatorStack.top());

                    if (t == "-" || t == "+")
                    {
                        operationhelp = DealWithAdditionorSubtraction(ValueStack, OperatorStack);
                        ValueStack.pop();
                        ValueStack.pop();
                        ValueStack.push(operationhelp);                    
                        
                        OperatorStack.pop();
                    }
                    //pops the parenthesis that we know will be there because it is inside a formula

                    OperatorStack.pop();
                    
                  
                    //Checks if the parenthesis were proceeded by a * or a /
                    if (OperatorStack.size() > 0)
                    {
                        NewInt = ValueStack.top();
                        ValueStack.pop();
                        // if the method returns false it means there was a divide by zero inside so it returns the appropriate error
                        double x;
            if (OperatorStack.top() == "*" || OperatorStack.top() == "/")
            {
                //does multiplication if needed
                if (OperatorStack.top() == "*")
                {
                    OperatorStack.pop();
                    x = ValueStack.top();
                    ValueStack.pop();
                    ValueStack.push(NewInt * x);
                }
                else
                {
                    OperatorStack.pop();
                    if (NewInt == 0)
                    {

                        throw 1;
                    }
                    else
                    {

                        x = ValueStack.top();
                        ValueStack.pop();
                        ValueStack.push(x / NewInt);
                    }
                }
            }
            else
            {
                ValueStack.push(NewInt);
            }
            continue;
                    }

                    continue;
                }
                // Uses a helper method to complete any + or - if needed then pushes the new token onto the  operatorstack
                else if (CurrentToken=="+" || CurrentToken=="-")
                {
                    if (OperatorStack.size() != 0)
                    {
                        if (OperatorStack.top() == "+" || OperatorStack.top() == "-")
                        {
                        operationhelp = DealWithAdditionorSubtraction(ValueStack, OperatorStack);
                        ValueStack.pop();
                        ValueStack.pop();
                        ValueStack.push(operationhelp);                        }
                    }
                    OperatorStack.push(CurrentToken);

                    continue;
                }

                // checks if the token is a integer if it is uses a helper method to deal with it.
                else if (is_numeric(CurrentToken))
                {
                    NewInt = std::stod(CurrentToken);
                   double x;
                   double y;
                   if (OperatorStack.size() > 0){
            if (OperatorStack.top() == "*" || OperatorStack.top() == "/")
            {
                //does multiplication if needed
                if (OperatorStack.top() == "*")
                {
                    OperatorStack.pop();
                    x = ValueStack.top();
                    ValueStack.pop();
                    
                    ValueStack.push(NewInt * x);
                }
                else
                {
                    OperatorStack.pop();
                    if (NewInt == 0)
                    {

                        throw 1;
                    }
                    else
                    {

                        x = ValueStack.top();
                        ValueStack.pop();
                        ValueStack.push(x / NewInt);
                    }
                }
            }
         else
            {
                ValueStack.push(NewInt);
            }
           
                   }
                   else
            {
                ValueStack.push(NewInt);
            }
            
            continue;
                }
                else
                {
                    // finally checks if the token is a variable according to the rules, if not throws an error.
                    //if it is it converts into a integer or throws an error if the variable is not representing an error
                    //once an integer it uses the same method as a normal integer to decide what to do.

                    try
                    {

                       // NewInt = lookup(CurrentToken);
                        double x;
            if (OperatorStack.top() == "*" || OperatorStack.top() == "/")
            {
                //does multiplication if needed
                if (OperatorStack.top() == "*")
                {
                    OperatorStack.pop();
                    x = ValueStack.top();
                    ValueStack.pop();
                    ValueStack.push(NewInt * ValueStack.top());
                }
                else
                {
                    OperatorStack.pop();
                    if (NewInt == 0)
                    {

                        throw 1;
                    }
                    else
                    {

                        x = ValueStack.top();
                        ValueStack.pop();
                        ValueStack.push(x / NewInt);
                    }
                }
            }
            else
            {
                ValueStack.push(NewInt);
            }
            continue;
                    }
                    catch (int e)
                    {
                        throw 1; 
                    }
                }
            }
            // now that the tokens are finished checks if the right conditions are met to give a result.
            // if there are no operators and one value returns the value
            if (OperatorStack.size() == 0)
            {
                NewInt = ValueStack.top();
                ValueStack.pop();
                return NewInt;
            }
            // if there is one operator a + or a - and two values it evaluates and returns the result else it throws a error
            else
            {

                        if(OperatorStack.top()!="("){
                        operationhelp = DealWithAdditionorSubtraction(ValueStack, OperatorStack);
                        ValueStack.pop();
                        ValueStack.pop();
                        ValueStack.push(operationhelp);
                        }
                NewInt = ValueStack.top();
                ValueStack.pop();
                return NewInt;            }
        }


        //https://stackoverflow.com/questions/29169153/how-do-i-verify-a-string-is-valid-double-even-if-it-has-a-point-in-it#:~:text=You%20could%20use%20std%3A%3A,setting%20the%20eof()%20flag.&text=You%20can%20also%20count%20how,string%20is%20a%20valid%20double.
        //The link for this code.
        bool Formula::is_numeric(std::string const &str)
        {
            auto result = double();
            auto i = std::istringstream(str);

            i >> result;

            return !i.fail() && i.eof();
        }
       
        /// <summary>
        /// When numbers needs to be added this program takes the integers and adds or subtracts them.
        /// </summary>
        /// <param name="ValueStack"></param>
        /// <param name="OperatorStack"></param>
        //FIXED FOR NOW
        double Formula::DealWithAdditionorSubtraction(std::stack<double> ValueStack, std::stack<std::string> OperatorStack)
        {
            double x;
            double y;
            if (OperatorStack.top() == "+")
            {
                OperatorStack.pop();
                x = ValueStack.top();
                ValueStack.pop();
                y = ValueStack.top();
                ValueStack.pop();

                return x+y;
            }
            else
            {
                OperatorStack.pop();
                x = ValueStack.top();
                ValueStack.pop();
                y = ValueStack.top();
                ValueStack.pop();
                return y-x;
            }
        }

     

        std::string Formula::GetString(char character)
        {
            // string class has a constructor
            // that allows us to specify size of
            // string as first parameter and character
            // to be filled in given size as second
            // parameter.
            std::string s(1, character);

            return s;
        }
        std::vector<std::string> Formula::GetVariables()
        {
            return variableStorer;
        }
        std::vector<std::string> Formula::GetTokens(std::string &formula)
        {
            std::vector<std::string> TokenTranslator;
            std::string TempToken;
            std::string Variable_Builder;
            int decimal_count = 0;
            int original_position;
            bool digit_search = false;

            for (int i = 0; i < formula.length(); i++)
            {

                if (!digit_search)
                {
                    original_position = i;
                }

                if (std::isalpha(formula.at(i)))
                {
                    digit_search = true;
                    Variable_Builder.assign(formula.substr(original_position, i - original_position + 1));
                    continue;
                }

                TempToken = GetString(formula.at(i));

                if (TempToken == "(" || TempToken == ")")
                {
                    if (digit_search)
                    {
                        digit_search = false;
                        variableStorer.push_back(Variable_Builder);
                        TokenTranslator.push_back(Variable_Builder);
                    }
                    TokenTranslator.push_back(TempToken);
                    continue;
                }
                else if (TempToken == "-" || TempToken == "+")
                {
                    if (digit_search)
                    {
                        digit_search = false;
                        variableStorer.push_back(Variable_Builder);
                        TokenTranslator.push_back(Variable_Builder);
                    }
                    TokenTranslator.push_back(TempToken);
                    continue;
                }
                else if (TempToken == "*" || TempToken == "/")
                {
                    if (digit_search)
                    {
                        digit_search = false;
                        variableStorer.push_back(Variable_Builder);
                        TokenTranslator.push_back(Variable_Builder);
                    }
                    TokenTranslator.push_back(TempToken);
                    continue;
                }

                else if (std::isdigit(formula.at(i)) || TempToken == ".")
                {
                    digit_search = true;
                    Variable_Builder.assign(formula.substr(original_position, i - original_position + 1));

                    continue;
                }
                else if (TempToken == " " && digit_search){
                digit_search = false;
                variableStorer.push_back(Variable_Builder);
                TokenTranslator.push_back(Variable_Builder);
                }

            }
            if (digit_search)
            {
                //ZACHARY GUNDERSEN ADD
                variableStorer.push_back(Variable_Builder);
                TokenTranslator.push_back(Variable_Builder);
            }
            return TokenTranslator;
        }}

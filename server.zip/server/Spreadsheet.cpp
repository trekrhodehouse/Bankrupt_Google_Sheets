#include "Spreadsheet.h"

namespace spreadsheet
{
	spreadsheet::spreadsheet(change sheet_history) {
		changeobject = sheet_history;
	}

	bool spreadsheet::spreadsheet::validate()
	{
		return false;
	}

	change spreadsheet::spreadsheet::getchange()
	{
		return changeobject;
	}

	bool spreadsheet::spreadsheet::push(std::string cellname, std::string cellcontents)
	{
		twostrings cell = twostrings(cellname, cellcontents);
		//TODO must add a way to check for circular dependincies and add cells to the dependency Graph object

		if (cellcontents[0] == '=') {
			try {
				SpreadsheetUtilities::Formula checker = SpreadsheetUtilities::Formula(cellcontents);
			}
			catch (int e)
			{
				return false;
			}
		}
		return changeobject.push(cellname, cellcontents);

	}

	twostrings spreadsheet::spreadsheet::revert(std::string stringname)
	{
		return changeobject.Revertdata(stringname);
	}

	// Note from Corey - you may want to return a boolean here (and the revert)
	// in the case that there are no more undos or redos to perform and the
	// operation is unsuccessful
	// and have me hand in a reference like so:
	// bool spreadsheet::spreadsheet::undo(std::string & affected_cell, std::string & previous_value);
	// or
	// bool spreadsheet::spreadsheet::undo(spreadsheet::twostrings & previous_cell);
	twostrings spreadsheet::spreadsheet::undo()
	{ //if the undo is empty then it returns an empty cellname and contents 
		// else it returns the current contents and name of a cell
		// does not need to check for circular dependencies but does need to change the dependency graph. NOTE I DECIDED TO DO THIS IN THE CHANGE OBJECT

		return changeobject.Undodata();
	}
}
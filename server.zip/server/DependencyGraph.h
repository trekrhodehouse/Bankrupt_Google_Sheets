#ifndef DEPENDENCY_GRAPH_H
#define DEPENDENCY_GRAPH_H
#include <iostream>
#include <string>
#include <map>
#include <vector>
	class DependencyGraph {
	private:
		int size;
		std::map<std::string, std::vector<std::string>>*Dependents;
		std::map<std::string, std::vector<std::string>>*Dependees;
	public:
		DependencyGraph();
		int Size();
		//public int this[std::string s]
		bool HasDependents(std::string s);
		bool HasDependees(std::string s);
		std::vector<std::string> GetDependents(std::string s);
		std::vector < std::string>GetDependees(std::string s);		
		void AddDependency(std::string s, std::string t);
		void RemoveDependency(std::string s, std::string t);
		void ReplaceDependents(std::string s, std::vector<std::string>newDependents);
	    void ReplaceDependees(std::string s, std::vector<std::string>newDependees);
		bool DependentContainsKey(std::string s);
		bool DependeeContainsKey(std::string s);
		void printDependents();
		void printDependees();
	};

#endif

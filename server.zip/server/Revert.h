#pragma once

#ifndef REVERT_H
#define REVERT_H
#include "twostrings.h"
#include <stack>
#include <string>

namespace spreadsheet
{

	class revert
	{

		std::string cellname;
	public:
		int size;
		int getsize();
		revert();
		void setcellname(std::string cellname);
		twostrings getTop();
		std::string getcellname();
		std::stack<std::string> values;
		~revert();
		revert(std::string cellname);

		twostrings pop();

		void push(std::string newvalue);
	};


}

#endif

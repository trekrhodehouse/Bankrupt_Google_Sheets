README DOCUMENTATION - CS3500 SPREADSHEET APPLICATION

AUTHORS: ZACHARY GUNDERSEN & JONATHAN DRANEY

Final version ready for release : 1.0.0 ; Completed Date 10/09/2020

All code that is not completely original was pulled from available code provided by the Professor, Daniel Kopta, or other teaching staff.
Absolutely everything else is completely original code, with some code regarding new material (like message boxes) inspired - but not ripped off from -
various tutorial and introductorial C# programming websites. Again, even if inspired by one of the aforementioned sources, all code not pulled from 
available class material is ENTIRELY ORIGINAL!

----------------------------------------------------------------------------------------------------------------------------------------------------------

DESIGN:

The SpreadsheetGui is based off the Model-View-Controller idea, as best we new students understand it. Contained within is all the core type functionality
of the various spreadsheet elements one would expect and were previous Problem Sets: formulas, variables, evaluations, contents as string or double, etc.
The model consists of the Spreadsheet class and all it contains. This type represents the Guts of all our data processes and variable memory.
The View is our GUI, which consists of the provided skeleton with a few additional elements. Added are the File and Help menu buttons. File 
contains: New, Save, Save As, Load, Close; all are operations that would behave exactly as expected to. Help opens a new panel that displays useful
information to new users. We have included three labels and three text fields contained within an additional panel below the menu buttons and above
the spreadsheet panel. Each label corresponds with the functionality of the text field it labels. The Contents field describes the contents of a selected
cell. The Name field details the name of the cell selected. The Value field represents the contents after evaluation of any given cell.

Any given cell can contain a number (as double), a string (like a column header), a variable (a cell name), a formula (an infix expression containing
numbers and variables), or a function(which contains a function keyword followed by a range of cells on which to perform the desired operation). The contents
are stored separate than the evaluated value, showing a user what formula or function or variable is being called upon in order to provide the end value.

Events are called within the GUI by clicking on buttons or pressing the enter key. These events methods we have abstained from leaving the bulk of our logic,
instead relegating the logic-heavy functions to helpers contained within the same class as the form events. 


As of now, the program builds and executes perfectly. Although there are always a myriad of quality-of-life improvements that could be made and we would
love to implement given enough time, the program seems to be, as far as we could test it with our limited time and brand-new knowledge of GUIs, mostly 
bug-free. We think it would be quite interesting to see a list of bugs begin to build up so we could see what bug-hungry users were able to find. When
dealing with a GUI as newbie programmers, we tested to ensure functionality; we did not as earnestly or thouroughly test it to break it, as we only have
so much time. Given a user that isn't entirely incompetent, our program will provide the functionality needed for a basic spreadsheet.


EASTER EGG! There are two Easter Eggs in this program. Don't read the code first! Your hint (also in help menu): Initials in Initials

----------------------------------------------------------------------------------------------------------------------------------------------------------

ADDITIONAL FUNCTIONALITY:

Our program may not look very nice, but we have implemented some highly important functionality every spreadsheet should have: Functions! We like to think
that the amount of effort and design implementing our functions was like doing an entirely original Problem Set, equivalent to the effort put into the 
Formula type as required for class. We spent much time on designing, developing, and inevitably debugging our all-new Function type. 

The Function type lets a user access one of functions that performs a range of data manipulations on a range of cells. Given the complicated
nature of Function development, we have implemented as of the date of this document's writing 5 full Functions for the user's pleasure and ease-of-use.
All Functions follow the same format: =Function_Name(Cell_Range_Start, Cell_Range_End), where the cell range must be either contained within one column
or one row.

The provided Functions are available in the help menu and are as follows:
	SUM - Sums the values of all cells in the given range
	AVG - Takes the average of all cells in the given range (equivalent of SUM/COUNT)
	MAX - Evaluates to the largest value of the cells in the given range
	MIN - Evaluates to the smallest value of the cells in the given range
	COUNT - Returns the number of cells in a range that contain elements

All Functions ignore cells that contain strings or have empty contents.

Given more time, more Functions could be added easily to improve the utility of our spreadsheet. As is, 6 hours on our additional functionality seemed
more than appropriate given the amount of time we have to complete the assignment in its entirety.

Our Function class was developed in 6 hours while we were commenting we realized how we could improve our function class greatly if we had more time
We would fix the function class so that instead of taking in a highly specific string we would make it much more usuable by having it input only a 
a range of variables and then rewritting our methods so that they were public to the user so that once they created a function object they could call 
the desired Function type such as Functionobject.Sum and this would return the current sum. Doing would greatly simplify and improve the usibility class
for different uses other than the spreadsheet currently our class is limited as it was generated for the specific use of our spreadsheet. 
Our class would still take a lookup for determining cells inside the range but while it is currently dependent on the formula class
We know we could change this by storing the range of cells first instead of going through the specific Function methods this would let us keep the full list
to stay aware of circular dependencies while calling any of the specific functions methods would return an up-to-date value which in terms of our spreadsheet  
would reevalute and store the new value whenever it was changed.


-----------------------------------------------------------------------------------------------------------------------------------------------------------

PROBLEMS / ADDITIONAL DESIRED FUNCTIONALITY:

There are, of course, a plethora of additional featurettes that we would love to have implemented. These things were barred from us due either to 
time constraints or our lack of knowledge when it comes to GUIs, as were are green and have learned everything we needed on the spot in order to 
implement even the basic GUI elements we have added. 

Things we would like to implements/improve/fix/etc.:
	-removing ability to click into Name/Value fields at all
	-present autofill on Function calls for -ease-of-use to user
	-error checking for literally everything, because users are stupid
	-arrow keys or wasd keys to move between cells
	-we were interested originally (as our additional functionality, for fun) in including a pixel art mode by changing cell dimensions, 
		but we couldn't figure out how to assign a color background to a single cell, instead of all cells
	-drawing on the GUI to indicate circular dependencies or other errors
	-allowing our Functions to take in ranges like (A1, C4) - instead of a single row or column - , and calculate each row or column 
		with the Function, then totalling those up
	-we had some fun ideas for additional Easter Egg code
	-we realized after completion of our program that 
	-And many, many, many more
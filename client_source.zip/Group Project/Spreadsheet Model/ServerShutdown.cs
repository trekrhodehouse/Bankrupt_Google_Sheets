﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace SpreadsheetUtilities
{
    [JsonObject(MemberSerialization.OptIn)]
    public class ServerShutdown
    {
        [JsonProperty(PropertyName = "messageType")]
        private string type;

       

        [JsonProperty(PropertyName = "message")]
        private string message;

        public ServerShutdown(string requestType, string shutdownMessage)
        {
            type = requestType;
            message = shutdownMessage;
        }
        
        public string getType()
        {
            return type;
        }

        public string getMessage()
        {
            return message;
        }
    }
}


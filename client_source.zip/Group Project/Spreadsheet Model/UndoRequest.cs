﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace SpreadsheetUtilities
{
    [JsonObject(MemberSerialization.OptIn)]
    public class UndoRequest
    {
        [JsonProperty(PropertyName = "requestType")]
        private string type;


        public UndoRequest(string requestType, string cellName)
        {
            type = requestType;
        }

        public string getType()
        {
            return type;
        }

    }
}

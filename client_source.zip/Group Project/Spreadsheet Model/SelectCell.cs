﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace SpreadsheetUtilities
{
    [JsonObject(MemberSerialization.OptIn)]
    public class SelectCell
    {
        [JsonProperty(PropertyName = "requestType")]
        private string type;

        [JsonProperty(PropertyName = "cellName")]
        private string name;

        public SelectCell(string requestType, string cellName)
        {
            type = requestType;
            name = cellName;
        }

        public string getType()
        {
            return type;
        }

        public string getName()
        {
            return name;
        }

    }
}

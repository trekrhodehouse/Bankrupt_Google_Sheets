﻿using System;
using System.Data;

namespace TestsforFormulaEvaluator
{
    class Program
    {
        static double Delegate(String s)
        {
            if (s.Equals("A6")) { 
            return 1;
                }
 else{throw new ArgumentException();
                }
        
        }
        static void Main(string[] args)
        {


            
            Console.WriteLine("" + FormulaEvaluator.Evaluator.Evaluate ("(8 - 1 + 3) * 6 - ((3 + 7) * 2)", Delegate));

            Console.ReadKey();
        }
    }
}

﻿namespace SS
{
    partial class SpreadsheetGui
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SpreadsheetGui));
            this.spreadsheetPanel1 = new SS.SpreadsheetPanel();
            this.cellContentsField = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.undoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textFieldsPanel = new System.Windows.Forms.Panel();
            this.cellEvalButton = new System.Windows.Forms.Button();
            this.cellValueLabel = new System.Windows.Forms.Label();
            this.cellNameLabel = new System.Windows.Forms.Label();
            this.cellContentsLabel = new System.Windows.Forms.Label();
            this.cellValueField = new System.Windows.Forms.TextBox();
            this.cellNameField = new System.Windows.Forms.TextBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.RevertButton = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.textFieldsPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // spreadsheetPanel1
            // 
            this.spreadsheetPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.spreadsheetPanel1.BackColor = System.Drawing.SystemColors.Control;
            this.spreadsheetPanel1.Location = new System.Drawing.Point(-2, 53);
            this.spreadsheetPanel1.Margin = new System.Windows.Forms.Padding(2);
            this.spreadsheetPanel1.Name = "spreadsheetPanel1";
            this.spreadsheetPanel1.Size = new System.Drawing.Size(588, 359);
            this.spreadsheetPanel1.TabIndex = 0;
            this.spreadsheetPanel1.Load += new System.EventHandler(this.spreadsheetPanel1_Load);
            // 
            // cellContentsField
            // 
            this.cellContentsField.Location = new System.Drawing.Point(64, 2);
            this.cellContentsField.Margin = new System.Windows.Forms.Padding(2);
            this.cellContentsField.Name = "cellContentsField";
            this.cellContentsField.Size = new System.Drawing.Size(124, 20);
            this.cellContentsField.TabIndex = 1;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(587, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.saveToolStripMenuItem1,
            this.saveToolStripMenuItem,
            this.loadToolStripMenuItem,
            this.closeToolStripMenuItem,
            this.undoToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.newToolStripMenuItem.Text = "New";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem1
            // 
            this.saveToolStripMenuItem1.Name = "saveToolStripMenuItem1";
            this.saveToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.saveToolStripMenuItem1.Text = "Save";
            this.saveToolStripMenuItem1.Click += new System.EventHandler(this.saveToolStripMenuItem1_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.saveToolStripMenuItem.Text = "Save As";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // loadToolStripMenuItem
            // 
            this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
            this.loadToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.loadToolStripMenuItem.Text = "Load";
            this.loadToolStripMenuItem.Click += new System.EventHandler(this.loadToolStripMenuItem_Click);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // undoToolStripMenuItem
            // 
            this.undoToolStripMenuItem.Name = "undoToolStripMenuItem";
            this.undoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.undoToolStripMenuItem.Text = "Undo";
            this.undoToolStripMenuItem.Click += new System.EventHandler(this.undoToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // textFieldsPanel
            // 
            this.textFieldsPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textFieldsPanel.Controls.Add(this.cellEvalButton);
            this.textFieldsPanel.Controls.Add(this.cellValueLabel);
            this.textFieldsPanel.Controls.Add(this.cellNameLabel);
            this.textFieldsPanel.Controls.Add(this.cellContentsLabel);
            this.textFieldsPanel.Controls.Add(this.cellValueField);
            this.textFieldsPanel.Controls.Add(this.cellNameField);
            this.textFieldsPanel.Controls.Add(this.cellContentsField);
            this.textFieldsPanel.Location = new System.Drawing.Point(0, 25);
            this.textFieldsPanel.Margin = new System.Windows.Forms.Padding(2);
            this.textFieldsPanel.Name = "textFieldsPanel";
            this.textFieldsPanel.Size = new System.Drawing.Size(582, 25);
            this.textFieldsPanel.TabIndex = 3;
            // 
            // cellEvalButton
            // 
            this.cellEvalButton.Location = new System.Drawing.Point(192, 2);
            this.cellEvalButton.Margin = new System.Windows.Forms.Padding(2);
            this.cellEvalButton.Name = "cellEvalButton";
            this.cellEvalButton.Size = new System.Drawing.Size(68, 19);
            this.cellEvalButton.TabIndex = 7;
            this.cellEvalButton.Text = "Evaluate";
            this.cellEvalButton.UseVisualStyleBackColor = true;
            this.cellEvalButton.Click += new System.EventHandler(this.cellEvalButton_Click);
            // 
            // cellValueLabel
            // 
            this.cellValueLabel.AutoSize = true;
            this.cellValueLabel.Location = new System.Drawing.Point(404, 5);
            this.cellValueLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.cellValueLabel.Name = "cellValueLabel";
            this.cellValueLabel.Size = new System.Drawing.Size(37, 13);
            this.cellValueLabel.TabIndex = 6;
            this.cellValueLabel.Text = "Value:";
            // 
            // cellNameLabel
            // 
            this.cellNameLabel.AutoSize = true;
            this.cellNameLabel.Location = new System.Drawing.Point(310, 5);
            this.cellNameLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.cellNameLabel.Name = "cellNameLabel";
            this.cellNameLabel.Size = new System.Drawing.Size(38, 13);
            this.cellNameLabel.TabIndex = 5;
            this.cellNameLabel.Text = "Name:";
            // 
            // cellContentsLabel
            // 
            this.cellContentsLabel.AutoSize = true;
            this.cellContentsLabel.Location = new System.Drawing.Point(9, 5);
            this.cellContentsLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.cellContentsLabel.Name = "cellContentsLabel";
            this.cellContentsLabel.Size = new System.Drawing.Size(52, 13);
            this.cellContentsLabel.TabIndex = 4;
            this.cellContentsLabel.Text = "Contents:";
            this.cellContentsLabel.Click += new System.EventHandler(this.cellContentsLabel_Click);
            // 
            // cellValueField
            // 
            this.cellValueField.BackColor = System.Drawing.SystemColors.Control;
            this.cellValueField.Location = new System.Drawing.Point(441, 2);
            this.cellValueField.Margin = new System.Windows.Forms.Padding(2);
            this.cellValueField.Name = "cellValueField";
            this.cellValueField.ReadOnly = true;
            this.cellValueField.Size = new System.Drawing.Size(123, 20);
            this.cellValueField.TabIndex = 3;
            // 
            // cellNameField
            // 
            this.cellNameField.Location = new System.Drawing.Point(351, 2);
            this.cellNameField.Margin = new System.Windows.Forms.Padding(2);
            this.cellNameField.Name = "cellNameField";
            this.cellNameField.ReadOnly = true;
            this.cellNameField.Size = new System.Drawing.Size(42, 20);
            this.cellNameField.TabIndex = 2;
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "sprd|";
            this.saveFileDialog1.Filter = "\"Spreadsheet files\"|*.sprd|All files|*.*";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "\"Spreadsheet files\"|*.sprd|All files|*.*";
            this.openFileDialog1.RestoreDirectory = true;
            // 
            // RevertButton
            // 
            this.RevertButton.Location = new System.Drawing.Point(192, 5);
            this.RevertButton.Margin = new System.Windows.Forms.Padding(2);
            this.RevertButton.Name = "RevertButton";
            this.RevertButton.Size = new System.Drawing.Size(68, 19);
            this.RevertButton.TabIndex = 8;
            this.RevertButton.Text = "Revert";
            this.RevertButton.UseVisualStyleBackColor = true;
            this.RevertButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // SpreadsheetGui
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(587, 410);
            this.Controls.Add(this.RevertButton);
            this.Controls.Add(this.textFieldsPanel);
            this.Controls.Add(this.spreadsheetPanel1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "SpreadsheetGui";
            this.Text = "PS6 Spreadsheet";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.textFieldsPanel.ResumeLayout(false);
            this.textFieldsPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private SS.SpreadsheetPanel spreadsheetPanel1;
        private System.Windows.Forms.TextBox cellContentsField;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.Panel textFieldsPanel;
        private System.Windows.Forms.TextBox cellNameField;
        private System.Windows.Forms.TextBox cellValueField;
        private System.Windows.Forms.Label cellValueLabel;
        private System.Windows.Forms.Label cellNameLabel;
        private System.Windows.Forms.Label cellContentsLabel;
        private System.Windows.Forms.Button cellEvalButton;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem undoToolStripMenuItem;
        private System.Windows.Forms.Button RevertButton;
    }
}


﻿/*
 *  Authors: Jonathan Draney and Zachary Gundersen
 *  Date: 10/05/2020
 *  
 *  This class is our Spreadsheet GUI itself. It contains all the events that are triggered
 *  by the gui components, as well as helper methods that perform the work those events need done.
 *  We have separated heavy logic from event methods as much as we could.
 */
using Newtonsoft.Json;
using SpreadsheetUtilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Security;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using Microsoft.VisualBasic;

namespace SS
{
    /// <summary>
    /// The SpreadsheetGui! Uses a SpreadsheetPanel, and our own panel that consists of several components, as well
    /// as a file menu with various optios. This hosts the functioning spreadsheet!
    /// </summary>
    public partial class SpreadsheetGui : Form
    {
        //members
        /// <summary>
        /// The Spreadsheet object that backs the GUI for data storage and manipulation
        /// </summary>
        Spreadsheet SpreadsheetGuts;

        /// <summary>
        /// Retain the column and row of the selction for passing into other methods without calling SpreadsheetPanels methods over and over
        /// </summary>
        private int Col, Row;
        /// <summary>
        /// Stores the pathname of a saved or loaded spreadsheet, which allows us to save without a dialog
        /// </summary>
        private string Pathname;

        private bool fileCheck = false;


        private Dictionary<int, string> selectorIDS = new Dictionary<int, string>();



        private SolidBrush selectionBrush = new SolidBrush(Color.FromArgb(255, 182, 193));



        private SpreadsheetController Control;

        /// <summary>
        /// The no arg constructor creates a new spreadsheet.
        /// </summary>
        public SpreadsheetGui(SpreadsheetController ctl)
        {
            InitializeComponent();

            Control = ctl;
            Control.InitialMessagesArrived += InitialMessageHandler;
            Control.UpdateMessageArrived += UpdateMessageHandler;
            Control.SelectionMessageArrived += SelectionMessageHandler;
            Control.DisconnectMessageArrived += DisconnectMessageHandler;
            Control.RequestErrorMessageArrived += RequestErrorMessageHandler;
            Control.ShutdownMessageArrived += ShutdownMessageHandler;

            Control.Error += ShowError;
            Control.Connected += HandleConnected;

            this.ActiveControl = cellContentsField;


            // This an example of registering a method so that it is notified when
            // an event happens.  The SelectionChanged event is declared with a
            // delegate that specifies that all methods that register with it must
            // take a SpreadsheetPanel as its parameter and return nothing.  So we
            // register the displaySelection method below.

            // This could also be done graphically in the designer, as has been
            // demonstrated in class.
            spreadsheetPanel1.SelectionChanged += displaySelection;
            spreadsheetPanel1.SetSelection(0, 0);
            Col = Row = 0;

            AcceptButton = cellEvalButton;
            string name = Interaction.InputBox("Enter a username", "Name Entry Box", "Name");
            Control.AssignName(name);
            string server = Interaction.InputBox("Enter Server Address", "Server Entry Box", "localhost");
            Control.Connect(server);
            //init members
            SpreadsheetGuts = new Spreadsheet(Validator, s => s.ToUpper(), "ps6");


            Pathname = "";

        }

        private void InitialMessageHandler(IEnumerable<string> messages)
        {

            if (!fileCheck)
            {
                var message = string.Join(Environment.NewLine, messages);

                Control.FileSend(Interaction.InputBox("Choose a file name from the list below.\n" + message, "File Box", "Defaultfile.txt"));
                fileCheck = true;
            }


        }


        private void UpdateMessageHandler(string message)
        {
           

                CellServerUpdate update = JsonConvert.DeserializeObject<CellServerUpdate>(message);

                SpreadsheetGuts.SetContentsOfCell(update.getName(), update.getContents());

                spreadsheetPanel1.SetValue(RowLetterToInt(update.getName().ElementAt(0)), int.Parse(update.getName().Substring(1)) - 1, SpreadsheetGuts.GetCellContents(update.getName()).ToString());

                spreadsheetPanel1.GetValue(9, 3, out string n1);
                spreadsheetPanel1.GetValue(25, 6, out string n2);
                if (n1 == "Halfway!" && n2 == "Getting there!") //Easter Egg Check
                {
                    OpenA();
                }

            
        }

        private void SelectionMessageHandler(string message)
        {
            ServerSelection selection = JsonConvert.DeserializeObject<ServerSelection>(message);

            
            if (selectorIDS.ContainsKey(selection.getSelectorID()))
            {
                spreadsheetPanel1.SetColor(RowLetterToInt(selectorIDS[selection.getSelectorID()].ElementAt(0)), int.Parse(selectorIDS[selection.getSelectorID()].Substring(1)) - 1, null);
                selectorIDS.Remove(selection.getSelectorID());
            }
                selectorIDS.Add(selection.getSelectorID(), selection.getCellName());
            spreadsheetPanel1.SetColor(RowLetterToInt(selection.getCellName().ElementAt(0)), int.Parse(selection.getCellName().Substring(1)) - 1, selectionBrush);


        }
        private void DisconnectMessageHandler(string message)
        {
            ServerDisconnect disconnect = JsonConvert.DeserializeObject<ServerDisconnect>(message);
            if (selectorIDS.ContainsKey(disconnect.getSelectorID()))
            {
                string cellName = selectorIDS[disconnect.getSelectorID()];
                selectorIDS.Remove(disconnect.getSelectorID());
                if (!selectorIDS.ContainsValue(cellName))
                {
                    spreadsheetPanel1.SetColor(RowLetterToInt(cellName.ElementAt(0)), int.Parse(cellName.Substring(1)) - 1, null);
                }

            }
        }
            private void RequestErrorMessageHandler(string message)
            {
                RequestError help = JsonConvert.DeserializeObject<RequestError>(message);

                MessageBox.Show(help.getMessage());
            }
            private void ShutdownMessageHandler(string message)
            {
                ServerShutdown help = JsonConvert.DeserializeObject<ServerShutdown>(message);
                ShowError(help.getMessage());


            }

            private void HandleConnected()
            {

            }

            private void ShowError(string err)
            {
                // Show the error
                MessageBox.Show(err);
                this.Invoke((MethodInvoker)delegate
                {
                    // close the form on the forms thread
                    this.Close();
                });

            }

            /// <summary>
            /// Creates a new spreadsheet from the given filename, or rather loads an existing spreadsheet.
            /// </summary>
            /// <param name="filename"></param>
            public SpreadsheetGui(string filename) : this(new SpreadsheetController())
        {
                //init members
                SpreadsheetGuts = new Spreadsheet(filename, Validator, s => s.ToUpper(), "ps6");


                foreach (string cellName in SpreadsheetGuts.GetNamesOfAllNonemptyCells())
                {
                    spreadsheetPanel1.SetValue(RowLetterToInt(cellName.ElementAt(0)), int.Parse(cellName.Substring(1)) - 1, SetCellValueField(cellName));
                }
                Pathname = filename;
            }


            /// <summary>
            /// Returns whether a variable name is valid. Or in this case, returns whether a cell is in the valid range of (A1, Z99).
            /// This method is used only to send to the Spreadsheet constructor as our spreadsheets validator.
            /// </summary>
            /// <param name="name"></param>
            /// <returns></returns>
            private bool Validator(string name)
            {
                string varPattern = @"^[A-Z][0-9]{1,2}$";
                return Regex.IsMatch(name, varPattern);
            }




            // Every time the selection changes, this method is called with the
            // Spreadsheet as its parameter.  We display the current time in the cell.
            //The bulk of logic has been relegated to a helper method instead of being contained within thus event

            private void displaySelection(SpreadsheetPanel ss)
            {
                updateSelection(ss);

                cellContentsField.Focus();
            }

            /// <summary>
            /// Updates the selection fields to display the newly selected cell's contents, name, and value. 
            /// </summary>
            /// <param name="ss"></param>
            private void updateSelection(SpreadsheetPanel ss)
            {
                ss.GetSelection(out Col, out Row);
                ss.GetValue(Col, Row, out string value);


                //set cell name field - a cell always has a name
                string rowLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                string cellName = "" + rowLetters.ElementAt(Col) + (Row + 1);
                cellNameField.Text = cellName;

                //if the cell is empty, we don't need to do any more work
                if (value == "")
                {
                    cellContentsField.Clear();
                    cellValueField.Clear();
                }
                SelectCell cellSelection = new SelectCell("selectCell", cellNameField.Text);
                Control.UpdateSelection(cellSelection);
                //set cell contents field
                SetCellContentsField();

                //set cell value field
                spreadsheetPanel1.SetValue(Col, Row, SetCellValueField());
            }


            /// <summary>
            /// Sets the contents field to display the contents of the selected cell.
            /// </summary>
            private void SetCellContentsField()
            {

                string cellName = cellNameField.Text;
                try
                {
                    if (Function.IsFunction(SpreadsheetGuts.GetCellContents(cellName).ToString()))
                    {
                        Function tempFunc = (Function)SpreadsheetGuts.GetCellContents(cellName);
                        cellContentsField.Text = tempFunc.ToString();
                    }
                    else
                    {
                        Formula tempFormula = (Formula)SpreadsheetGuts.GetCellContents(cellName);
                        cellContentsField.Text = "=" + tempFormula.ToString();
                    }
                }
                catch (Exception)
                {
                    cellContentsField.Text = SpreadsheetGuts.GetCellContents(cellName).ToString();
                }
            }

            /// <summary>
            /// Sets the value field to display the value of the selected cell.
            /// </summary>
            /// <returns></returns>
            private string SetCellValueField()
            {
                string cellName = cellNameField.Text;

                object cellVal = SpreadsheetGuts.GetCellValue(cellName);

                string cellValue;

                if (cellVal is FormulaError)
                {
                    cellValue = cellValueField.Text = "Formula Error";
                }
                else if (cellVal is FunctionError)
                {
                    cellValue = cellValueField.Text = "Function Error";
                }
                else
                {
                    cellValue = cellValueField.Text = cellVal.ToString();
                }

                return cellValue;
            }

            /// <summary>
            /// Sets the value field with the value of the cell with the provided name.
            /// </summary>
            /// <param name="cellName"></param>
            /// <returns></returns>
            private string SetCellValueField(string cellName)
            {
                object cellVal = SpreadsheetGuts.GetCellValue(cellName);

                string cellValue;
                if (cellVal is FormulaError)
                {
                    cellValue = cellValueField.Text = "Formula Error";
                }
                else
                {
                    cellValue = cellValueField.Text = cellVal.ToString();
                }

                return cellValue;
            }

            /// <summary>
            /// Returns the integer representation of the row letter.
            /// </summary>
            /// <param name="letter"></param>
            /// <returns></returns>
            private int RowLetterToInt(char letter)
            {
                string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                return alphabet.IndexOf(letter);
            }



            // Deals with the New menu
            private void newToolStripMenuItem_Click(object sender, EventArgs e)
            {
                // Tell the application context to run the form on the same
                // thread as the other forms.
                SpreadsheetApplicationContext.getAppContext().RunForm(new SpreadsheetGui(new SpreadsheetController()));
            }

            // Deals with the Close menu
            /// <summary>
            /// Closes the window. If the user has unsaved changes, displays a warning.
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            private void closeToolStripMenuItem_Click(object sender, EventArgs e)
            {
                if (SaveWarning())
                {
                    Close();
                }
            }

            //on loading a form
            /// <summary>
            /// When loading the form, sets the name field to A1 as the default and displays its contents and value, if there are any (as if
            /// loaded from an existing spreadsheet). Focuses on the contents field so the user doesn't have to.
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            private void Form1_Load(object sender, EventArgs e)
            {
                cellNameField.Text = "A1";

                SetCellContentsField();

                SetCellValueField();

                cellContentsField.Focus();
            }

            private void spreadsheetPanel1_Load(object sender, EventArgs e)
            {

            }

            /// <summary>
            /// Saves the document
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            private void saveToolStripMenuItem_Click(object sender, EventArgs e)
            {
                SaveSpreadsheet();
            }


            private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
            {
                MessageBox.Show("File was not saved.");
            }

            /// <summary>
            /// Displays a save dialog. If the users cancels, does nothing. If the user saves, saves the pathname into the class member for future use.
            /// </summary>
            private void SaveSpreadsheet()
            {
                saveFileDialog1.ShowDialog();

                if (saveFileDialog1.FileName == "")
                {

                }
                else
                {
                    SpreadsheetGuts.Save(Pathname = saveFileDialog1.FileName);
                }
            }

            /// <summary>
            /// Loads a spreadsheet into the existing window, if the spreadsheet exists.
            /// </summary>
            private void LoadSpreadsheet()
            {
                //alerts the user if the have unsaved changes. If they cancel, returns the method before any work is done.
                if (!SaveWarning())
                {
                    return;
                }
                //shows the open dialog
                openFileDialog1.ShowDialog();
                if (openFileDialog1.FileName == "")
                {
                    //if the user cnacels or opens on an empty name, do nothing
                }
                else
                {
                    try
                    {
                        //the following line opens the document in a new window, which we decided against
                        //SpreadsheetApplicationContext.getAppContext().RunForm(new Form1(openFileDialog1.FileName));
                        //instead, we chose to load it into the existing spreadsheet by assigning the spreadsheet to the loaded document
                        SpreadsheetGuts = new Spreadsheet(openFileDialog1.FileName, Validator, s => s.ToUpper(), "ps6");
                        //fills the spreadsheetPanel cells with their appropriate values from the loaded document
                        foreach (string cellName in SpreadsheetGuts.GetNamesOfAllNonemptyCells())
                        {
                            spreadsheetPanel1.SetValue(RowLetterToInt(cellName.ElementAt(0)), int.Parse(cellName.Substring(1)) - 1, SetCellValueField(cellName));
                        }
                        Pathname = openFileDialog1.FileName;
                    }
                    catch (Exception e)
                    {
                        MessageBox.Show(e.Message);
                        //LoadSpreadsheet(); //wanted to try and call the load again if it failed, but this had some unintended consequences
                    }
                }
            }

            /// <summary>
            /// Checks to see if the spreadsheet has changes. If it does, then warns the user they might lose unsaved changes using a message box 
            /// with buttons
            /// </summary>
            /// <returns></returns>
            private bool SaveWarning()
            {
                if (SpreadsheetGuts.Changed == true)
                {
                    DialogResult result = MessageBox.Show("You are about to lose any unsaved changes. Proceed?", "Unsaved Changes", MessageBoxButtons.OKCancel);
                    if (result == DialogResult.OK)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                return true;
            }

            /// <summary>
            /// Loads a new spreadsheet
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            private void loadToolStripMenuItem_Click(object sender, EventArgs e)
            {
                LoadSpreadsheet();
            }

            /// <summary>
            /// Displays the help window by creating a new HelpForm
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            private void helpToolStripMenuItem_Click(object sender, EventArgs e)
            {
                SpreadsheetApplicationContext.getAppContext().RunForm(new HelpForm());
            }

            /// <summary>
            /// If the user hasn't saved a new document before, opens the save dialog. Otherwise, saves the document by overwriting the 
            /// document with the same name, without a prompt.
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            private void saveToolStripMenuItem1_Click(object sender, EventArgs e)
            {
                if (String.IsNullOrEmpty(Pathname))
                {
                    SaveSpreadsheet();
                }
                else
                {
                    SpreadsheetGuts.Save(Pathname);
                }
            }

            /// <summary>
            /// Triggered when the user hits Enter or clicks on the Evaluate button
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            private void cellEvalButton_Click(object sender, EventArgs e)
            {


                EvaluateSelection();
            }

            //Evaluates the contents of the selected cell
            private void EvaluateSelection()
            {

               /* if (!SpreadsheetGuts.ContentsCheck(cellNameField.Text, cellContentsField.Text))
                {
                    MessageBox.Show("Invalid cell contents. Please try again.");
                    cellContentsField.Clear();
                    return;

                }*/


                EditCellRequest edit = new EditCellRequest("editCell", cellNameField.Text, cellContentsField.Text);
                Control.SendEdit(edit);




            }

            //Revert Button
            private void button1_Click(object sender, EventArgs e)
            {
            
                RevertRequest revert = new RevertRequest("revertCell", cellNameField.Text);
                Control.RevertSend(revert);
            
            }

            private void undoToolStripMenuItem_Click(object sender, EventArgs e)
            {
            
                UndoRequest undo = new UndoRequest("undo");
                Control.UndoSend(undo);
                
            }

            private void cellContentsLabel_Click(object sender, EventArgs e)
            {

            }

        private void namesOfSelectorsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }


        /// <summary>
        /// 
        /// </summary>
        private void OpenA()
            {
                for (int i = 0; i < 99; i++)
                {
                    for (int j = 0; j < 26; j++)
                    {
                        spreadsheetPanel1.SetValue(j, i, "JD & ZG Rule!");
                    }
                }
            }



        }
    }
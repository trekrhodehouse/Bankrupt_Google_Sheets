﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Text.RegularExpressions;
using NetworkUtil;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;



namespace SS
{
    public class SpreadsheetController
    {
        public delegate void MessageHandler(IEnumerable<string> messages);
        public event MessageHandler MessagesArrived;

        public delegate void ConnectedHandler();
        public event ConnectedHandler Connected;

        public delegate void ErrorHandler(string err);
        public event ErrorHandler Error;

        public delegate void ServerUpdateHandler();
        public event ServerUpdateHandler UpdateArrived;



        // keeps track of the name of the player
        private string userName;
        // keeps track of the player tank's ID
        private int userID;


        /// <summary>
        /// State representing the connection with the server
        /// </summary>
        SocketState theServer = null;

        public SpreadsheetController()
        {

        }

        /// <summary>
        /// Sets player name to the name typed in the text box.
        /// </summary>
        /// <param name="name"></param>
        public void AssignName(string name)
        {
            userName = name;
        }

        /// <summary>
        /// Begins the process of connecting to the server
        /// </summary>
        /// <param name="addr"></param>
        public void Connect(string addr)
        {
            Networking.ConnectToServer(OnConnect, addr, 11000);
        }
        /// <summary>
        /// Method to be invoked by the networking library when a connection is made
        /// </summary>
        /// <param name="state"></param>
        private void OnConnect(SocketState state)
        {
            if (state.ErrorOccured)
            {
                // inform the view
                Error("Error connecting to server");
                return;
            }

            // inform the view
            Connected();

            theServer = state;

            // send the player's name to the server
            Networking.Send(theServer.TheSocket, userName);

            // Start an event loop to receive messages from the server
            state.OnNetworkAction = ReceiveMessage;
            Networking.GetData(state);
        }
        /// <summary>
        /// Method to be invoked by the networking library when  data is available
        /// </summary>
        /// <param name="state"></param>
        private void ReceiveMessage(SocketState state)
        {
            if (state.ErrorOccured)
            {
                // inform the view
                Error("Lost connection to server");
                return;
            }
            ProcessMessages(state);

            // Continue the event loop
            Networking.GetData(state);

            // Notify any listeners (the view) that a new game world has arrived from the server
            if (UpdateArrived != null)
            {
                UpdateArrived();
            }

           
        }



        /// <summary>
        /// Checks to ensure a received message is a complete JSON wall. Returns false if any of the JSON properties are not present.
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private bool IsCompleteUpdateJSON(string message)
        {
            // messages should end with newline
            if (message[message.Length - 1] == '\n')
            {
                JToken token;
                JObject obj = JObject.Parse(message);

                //Checks to make sure all JTokens necessary to create a wall object are present.
                token = obj["messageType"];
                if (token == null)
                    return false;

                token = obj["cellName"];
                if (token == null)
                    return false;

                token = obj["contents"];
                if (token == null)
                    return false;
            }
            else
            {
                return false;
            }

            // If all tokens are present, returns true.
            return true;
        }

        /// <summary>
        /// Checks to ensure a received message is a complete JSON wall. Returns false if any of the JSON properties are not present.
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private bool IsCompleteServerSelectionJSON(string message)
        {
            // messages should end with newline
            if (message[message.Length - 1] == '\n')
            {
                JToken token;
                JObject obj = JObject.Parse(message);

                //Checks to make sure all JTokens necessary to create a wall object are present.
                token = obj["messageType"];
                if (token == null)
                    return false;

                token = obj["cellName"];
                if (token == null)
                    return false;

                token = obj["selector"];
                if (token == null)
                    return false;

                token = obj["selectorName"];
                if (token == null)
                    return false;
            }
            else
            {
                return false;
            }

            // If all tokens are present, returns true.
            return true;
        }

        /// <summary>
        /// Checks to ensure a received message is a complete JSON wall. Returns false if any of the JSON properties are not present.
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private bool IsCompleteDisconnectJSON(string message)
        {
            // messages should end with newline
            if (message[message.Length - 1] == '\n')
            {
                JToken token;
                JObject obj = JObject.Parse(message);

                //Checks to make sure all JTokens necessary to create a wall object are present.
                token = obj["messageType"];
                if (token == null)
                    return false;

                token = obj["user"];
                if (token == null)
                    return false;


            }
            else
            {
                return false;
            }

            // If all tokens are present, returns true.
            return true;
        }

        private bool IsCompleteRequestErrorJSON(string message)
        {
            // messages should end with newline
            if (message[message.Length - 1] == '\n')
            {
                JToken token;
                JObject obj = JObject.Parse(message);

                //Checks to make sure all JTokens necessary to create a wall object are present.
                token = obj["messageType"];
                if (token == null)
                    return false;

                token = obj["cellName"];
                if (token == null)
                    return false;

                token = obj["message"];
                if (token == null)
                    return false;

            }
            else
            {
                return false;
            }

            // If all tokens are present, returns true.
            return true;
        }

        private bool IsCompleteShutdownJSON(string message)
        {
            // messages should end with newline
            if (message[message.Length - 1] == '\n')
            {
                JToken token;
                JObject obj = JObject.Parse(message);

                //Checks to make sure all JTokens necessary to create a wall object are present.
                token = obj["messageType"];
                if (token == null)
                    return false;

                token = obj["message"];
                if (token == null)
                    return false;

            }
            else
            {
                return false;
            }

            // If all tokens are present, returns true.
            return true;
        }

        /// <summary>
        /// Process any buffered messages separated by '\n'
        /// Then inform the view
        /// </summary>
        /// <param name="state"></param>
        private void ProcessMessages(SocketState state)
        {
            string totalData = state.GetData();
            string[] parts = Regex.Split(totalData, @"(?<=[\n])");
            StringBuilder sb = new StringBuilder();

            // Loop until we have processed all messages.
            // We may have received more than one.

            List<string> newMessages = new List<string>();
            foreach (string p in parts)
            {
                //Empty string check.
                if (p != "")
                {
                    //All messages should begin with a '{'.
                    if (p[0] == '{')
                    {
                        //Uses the helper method to check if the message is a complete wall JSON.
                        if (IsCompleteUpdateJSON(p))
                        {
                            lock (theWorld.GetWalls())
                            {
                                Walls newWall = JsonConvert.DeserializeObject<Walls>(p);
                                if (!theWorld.GetWalls().ContainsKey(newWall.GetID()))
                                {
                                    theWorld.AddWall(newWall);
                                }
                            }
                        }

                        //Uses the helper method to check if the message is a complete tank JSON.
                        if (IsCompleteServerSelectionJSON(p))
                        {
                            lock (theWorld.GetTanks())
                            {
                                Tank newTank = JsonConvert.DeserializeObject<Tank>(p);
                                if (!theWorld.GetTanks().ContainsKey(newTank.GetID()))
                                {
                                    theWorld.AddTank(newTank);
                                }
                                else
                                {
                                    //If a player disconnects, their ID is removed from the dictionary.
                                    if (!newTank.GetDisconnected())
                                        theWorld.ChangeTank(newTank);
                                    else
                                        theWorld.RemoveTank(newTank.GetID());
                                }
                            }
                        }

                        //Uses the helper method to check if the message is a complete projectile JSON.
                        if (IsCompleteDisconnectJSON(p))
                        {
                            lock (theWorld.GetProjectiles())
                            {
                                Projectile newProj = JsonConvert.DeserializeObject<Projectile>(p);
                                if (!theWorld.GetProjectiles().ContainsKey(newProj.GetID()))
                                {
                                    theWorld.AddProjectile(newProj);
                                }
                                else
                                {
                                    //If a projectile is dead, they are removed from the dictionary.
                                    if (!newProj.GetDied())
                                        theWorld.ChangeProjectile(newProj);
                                    else
                                        theWorld.RemoveProjectile(newProj.GetID());
                                }
                            }
                        }

                        //Uses the helper method to check if the message is a complete beam JSON.
                        if (IsCompleteRequestErrorJSON(p))
                        {
                            lock (theWorld.GetBeams())
                            {
                                Beam newBeam = JsonConvert.DeserializeObject<Beam>(p);
                                if (!theWorld.GetBeams().ContainsKey(newBeam.GetID()))
                                {
                                    //Gets the current framecount and sets it within the beam object.
                                    //This makes timing the beam object much easier.
                                    newBeam.SetFrameOrigin(theWorld.GetFrameCount());
                                    theWorld.AddBeam(newBeam);
                                }
                                else
                                {
                                    theWorld.RemoveBeam(newBeam.GetID());
                                    theWorld.AddBeam(newBeam);
                                }
                            }
                        }

                        //Uses the helper method to check if the message is a complete powerup JSON.
                        if (IsCompleteShutdownJSON(p))
                        {

                            lock (theWorld.GetPowerups())
                            {
                                Powerup newPower = JsonConvert.DeserializeObject<Powerup>(p);
                                if (!theWorld.GetPowerups().ContainsKey(newPower.GetID()))
                                {
                                    theWorld.AddPowerup(newPower);
                                }
                                else
                                {
                                    if (newPower.GetDied())
                                        theWorld.RemovePowerup(newPower.GetID());
                                }
                            }
                        }
                    }

                }

                // Ignore empty strings added by the regex splitter
                if (p.Length == 0)
                    continue;
                // The regex splitter will include the last string even if it doesn't end with a '\n',
                // So we need to ignore it if this happens. 
                if (p[p.Length - 1] != '\n')
                    break;



                // build a list of messages to send to the view
                newMessages.Add(p);

                // Then remove it from the SocketState's growable buffer
                state.RemoveData(0, p.Length);
            }

            // inform the view
            MessagesArrived(newMessages);
        }


    }
}

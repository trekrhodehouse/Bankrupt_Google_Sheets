﻿// Skeleton written by Joe Zachary for CS 3500, September 2013
// Read the entire skeleton carefully and completely before you
// do anything else!

// Version 1.1 (9/22/13 11:45 a.m.)

// Change log:
//  (Version 1.1) Repaired mistake in GetTokens
//  (Version 1.1) Changed specification of second constructor to
//                clarify description of how validation works

// (Daniel Kopta) 
// Version 1.2 (9/10/17) 

// Change log:
//  (Version 1.2) Changed the definition of equality with regards
//                to numeric tokens


using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace SpreadsheetUtilities
{
    /// <summary>
    /// Represents formulas written in standard infix notation using standard precedence
    /// rules.  The allowed symbols are non-negative numbers written using double-precision 
    /// floating-point syntax (without unary preceeding '-' or '+'); 
    /// variables that consist of a letter or underscore followed by 
    /// zero or more letters, underscores, or digits; parentheses; and the four operator 
    /// symbols +, -, *, and /.  
    /// 
    /// Spaces are significant only insofar that they delimit tokens.  For example, "xy" is
    /// a single variable, "x y" consists of two variables "x" and y; "x23" is a single variable; 
    /// and "x 23" consists of a variable "x" and a number "23".
    /// 
    /// Associated with every formula are two delegates:  a normalizer and a validator.  The
    /// normalizer is used to convert variables into a canonical form, and the validator is used
    /// to add extra restrictions on the validity of a variable (beyond the standard requirement 
    /// that it consist of a letter or underscore followed by zero or more letters, underscores,
    /// or digits.)  Their use is described in detail in the constructor and method comments.
    /// </summary>
    public class Formula
    {
        //the array that stores the tokens of the formula for future use
        private String[] TokenStorer;
        /// <summary>
        /// Creates a Formula from a string that consists of an infix expression written as
        /// described in the class comment.  If the expression is syntactically invalid,
        /// throws a FormulaFormatException with an explanatory Message.
        /// 
        /// The associated normalizer is the identity function, and the associated validator
        /// maps every string to true.  
        /// </summary>

        public Formula(String formula) :
            this(formula, s => s, s => true)
        {
        }

        /// <summary>
        /// Creates a Formula from a string that consists of an infix expression written as
        /// described in the class comment.  If the expression is syntactically incorrect,
        /// throws a FormulaFormatException with an explanatory Message.
        /// 
        /// The associated normalizer and validator are the second and third parameters,
        /// respectively.  
        /// 
        /// If the formula contains a variable v such that normalize(v) is not a legal variable, 
        /// throws a FormulaFormatException with an explanatory message. 
        /// 
        /// If the formula contains a variable v such that isValid(normalize(v)) is false,
        /// throws a FormulaFormatException with an explanatory message.
        /// 
        /// Suppose that N is a method that converts all the letters in a string to upper case, and
        /// that V is a method that returns true only if a string consists of one letter followed
        /// by one digit.  Then:
        /// 
        /// new Formula("x2+y3", N, V) should succeed
        /// new Formula("x+y3", N, V) should throw an exception, since V(N("x")) is false
        /// new Formula("2x+y3", N, V) should throw an exception, since "2x+y3" is syntactically incorrect.
        /// </summary>
        public Formula(String formula, Func<string, string> normalize, Func<string, bool> isValid)
        {
            TokenStorer = GetTokens(formula).ToArray();
            int NumberOfRP = 0;
            int NumberOfLP = 0;


            if (TokenStorer.Length == 0)
            {
                throw new FormulaFormatException("A formula needs at least one token, please try adding at least one token");

            }
            for (int i = 0; i < TokenStorer.Length; i++)
            {

                if (NumberOfLP > NumberOfRP)
                {
                    throw new FormulaFormatException("There is a misplaced right parenthesis, possibly too early or an extra one");
                }
                string CurrentString = TokenStorer[i];
                String NextString = "";


                if (IsANumber(CurrentString) || IsAnOperator(CurrentString) || CurrentString == "(" || CurrentString == ")")
                {
                    if (CurrentString == "(")
                    {
                        NumberOfRP++;
                    }
                    if (CurrentString == ")")
                    {
                        NumberOfLP++;
                    }
                }

                else
                {
                    if (IsAVariable(CurrentString, normalize, isValid))
                    {
                        TokenStorer[i] = normalize(CurrentString);
                    }
                }

                if (i < TokenStorer.Length - 1)
                {
                    NextString = TokenStorer[i + 1];
                }



                if (i == 0 && CurrentString != "(" && !IsANumber(CurrentString) && !IsAValidVariable(CurrentString))
                {
                    throw new FormulaFormatException("This formula begins with an invalid token, You could add a valid token (, a number, or a variable. Or delete existing first token");
                }
                if (i == TokenStorer.Length - 1 && CurrentString != ")" && !IsANumber(CurrentString) && !IsAValidVariable(CurrentString))
                {
                    throw new FormulaFormatException("This formula ends with an invalid token, You could add a valid token ), a number, or a variable. Or delete existing last token");
                }
                if (CurrentString == "(" || IsAnOperator(CurrentString))
                {
                    if (NextString != "(" && !IsANumber(NextString) && !IsAValidVariable(NextString))
                    {
                        throw new FormulaFormatException("There is a token that is either a \"(\", or a operator \"*, /, +, -\" that is not followed by a number or a variable or a opening parethesis fix this by removing an errant token or adding an appropriate token ");

                    }

                }
                if (CurrentString == ")" || IsANumber(CurrentString) || IsAValidVariable(CurrentString))
                {
                    if (NextString != ")" && NextString != "" && !IsAnOperator(NextString))
                    {
                        throw new FormulaFormatException("there is a token that is either a \")\", or a number or a variable that is not followed by a operator \"*, /, +, -\" or a closing parethesis fix this by removing an errant token or adding an appropriate token ");
                    }
                }














            }
            if (NumberOfLP != NumberOfRP)
            {
                throw new FormulaFormatException("this formula has an unblanced number of parenthesis please examine the formula and remove the items causing the embalence.");
            }

        }
        /// <summary>
        /// this takes a token passed to it and determines if it is a number
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public static bool IsANumber(String s)

        {

            return Double.TryParse(s, out double result);

        }
        /// <summary>
        /// takes a string of code and determines if it is a variable after normalizing and validating
        /// </summary>
        /// <param name="s"></param>
        /// <param name="normalize"></param>
        /// <param name="isValid"></param>
        /// <returns></returns>
        public static bool IsAVariable(String s, Func<string, string> normalize, Func<string, bool> isValid)
        {


            if (IsAValidVariable(s))
            {
                try
                {
                    IsAValidVariable(normalize(s));
                }
                catch (FormulaFormatException)
                {
                    throw new FormulaFormatException("The normalizer function passed into the method made this variable no longer valid try a new normalizer");
                }
                if (isValid(normalize(s)))
                {

                    return true;
                }
                else
                {
                    throw new FormulaFormatException("There is a token " + s + " that is not a legal variable according to the Validator fix this by deleting or correcting the token");

                }
            }
            else
            {
                return false;
            }

        }


        /// <summary>
        /// a simpler method that checks if the token input is a valid variable. this is used when you have already checked the validator and stored 
        /// it in the token storage does not revalidate in order to simplify and for methods that don't have access to the validator.
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>    
        public static bool IsAValidVariable(String s)
        {
            if (IsANumber(s) || IsAnOperator(s) || s == "(" || s == ")")
            {
                return false;
            }

            String varPattern = @"[a-zA-Z_](?: [a-zA-Z_]|\d)*";
            if (Regex.IsMatch(s, varPattern))
            {
                return true;

            }
            else
            {
                throw new FormulaFormatException("There is a token " + s + " that is not a legal variable fix this by deleting or correcting the token");
            }
        }
        /// <summary>
        /// this is a check if the token passed is an operator used when checking the next string and or current string
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public static bool IsAnOperator(String s)
        {
            if (s == "*" || s == "/" || s == "+" || s == "-")
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Evaluates this Formula, using the lookup delegate to determine the values of
        /// variables.  When a variable symbol v needs to be determined, it should be looked up
        /// via lookup(normalize(v)). (Here, normalize is the normalizer that was passed to 
        /// the constructor.)
        /// 
        /// For example, if L("x") is 2, L("X") is 4, and N is a method that converts all the letters 
        /// in a string to upper case:
        /// 
        /// new Formula("x+7", N, s => true).Evaluate(L) is 11
        /// new Formula("x+7").Evaluate(L) is 9
        /// 
        /// Given a variable symbol as its parameter, lookup returns the variable's value 
        /// (if it has one) or throws an ArgumentException (otherwise).
        /// 
        /// If no undefined variables or divisions by zero are encountered when evaluating 
        /// this Formula, the value is returned.  Otherwise, a FormulaError is returned.  
        /// The Reason property of the FormulaError should have a meaningful explanation.
        ///
        /// This method should never throw an exception.
        /// </summary>
        public object Evaluate(Func<string, double> lookup)
        {
            Stack<String> OperatorStack = new Stack<String>();
            Stack<double> ValueStack = new Stack<Double>();


            string[] substrings = System.Text.RegularExpressions.Regex.Split(this.ToString(), "(\\()|(\\))|(-)|(\\+)|(\\*)|(/)");
            // Splits string

            //Trims all leading and trailing white space from each token
            for (int i = 0; i < substrings.Length; i++)
            {
                substrings[i] = substrings[i].Trim();

            }

            //goes through all tokens to evaluate 
            foreach (string CurrentToken in substrings)
            {
                // dismisses any empty strings. 
                if (CurrentToken.Trim().Equals(""))
                {
                    continue;
                }
                double NewInt;
                // determins if the token is one of the three that only needs to be pushed into the stack, 
                if (CurrentToken.Equals("(") || CurrentToken.Equals("*") || CurrentToken.Equals("/"))
                {

                    OperatorStack.Push(CurrentToken);
                    continue;
                }
                // proccesses when the next token is an ) 
                else if (CurrentToken.Equals(")"))
                {

                    string t = OperatorStack.Peek();

                    if (t == "-" || t == "+")
                    {
                        DealWithAdditionorSubtraction(ValueStack, OperatorStack);
                    }
                    //pops the parenthesis that we know will be there because it is inside a formula

                    OperatorStack.Pop();
                    //Checks if the parenthesis were proceeded by a * or a /
                    if (OperatorStack.Count() > 0)
                    {
                        // if the method returns false it means there was a divide by zero inside so it returns the appropriate error
                        if (!PerformManipulationWithDouble(ValueStack.Pop(), ValueStack, OperatorStack))
                        {
                            return new FormulaError("there was a division by zero find the zero and remove it");

                        }
                    }



                    continue;
                }
                // Uses a helper method to complete any + or - if needed then pushes the new token onto the  operatorstack
                else if (CurrentToken.Equals("+") || CurrentToken.Equals("-"))
                {
                    if (OperatorStack.Count != 0)
                    {
                        if (OperatorStack.IsOnTop("+") || OperatorStack.IsOnTop("-"))
                        {
                            DealWithAdditionorSubtraction(ValueStack, OperatorStack);

                        }

                    }
                    OperatorStack.Push(CurrentToken);

                    continue;
                }


                // checks if the token is a integer if it is uses a helper method to deal with it. 
                else if (double.TryParse(CurrentToken, out NewInt))
                {
                    if (!PerformManipulationWithDouble(NewInt, ValueStack, OperatorStack))
                    {

                        return new FormulaError("there was a division by zero find the zero and remove it");
                    }


                }
                else
                {
                    // finally checks if the token is a variable according to the rules, if not throws an error. 
                    //if it is it converts into a integer or throws an error if the variable is not representing an error 
                    //once an integer it uses the same method as a normal integer to decide what to do.

                    try
                    {


                        double ValueofVariable = lookup(CurrentToken);
                        if (!PerformManipulationWithDouble(ValueofVariable, ValueStack, OperatorStack))
                        {
                            return new FormulaError("there was a division by zero find the zero and remove it");
                        }
                    }
                    catch (ArgumentException e)
                    {
                        return new FormulaError("This variable does not have an assigned value");

                    }



                }

            }
            // now that the tokens are finished checks if the right conditions are met to give a result.
            // if there are no operators and one value returns the value
            if (OperatorStack.Count == 0)
            {

                return ValueStack.Pop();



            }
            // if there is one operator a + or a - and two values it evaluates and returns the result else it throws a error
            else
            {

                DealWithAdditionorSubtraction(ValueStack, OperatorStack);
                return ValueStack.Pop();







            }




        }






        /// <summary>
        /// takes the int that needs to be dealt with and decides if it needs to be pushed into the stack or multiplied or divided by a previous integer
        /// then pushed. also used for when exiting a parenthesis to see if there is a * or a / 
        /// this method returns true in every case except if there is a division by zero attempted in which case it returns false it returns false so the main method can see a division by zero accured and return a formulaerror
        /// </summary>
        /// <param name="NumberToBeManipulated"></param>
        /// <param name="ValueStack"></param>
        /// <param name="OperatorStack"></param>
        public static bool PerformManipulationWithDouble(double NumberToBeManipulated, Stack<double> ValueStack, Stack<String> OperatorStack)
        {

            if (OperatorStack.IsOnTop("*") || OperatorStack.IsOnTop("/"))
            {
               //does multiplication if needed
                if (OperatorStack.Pop().Equals("*"))
                {
                    ValueStack.Push(NumberToBeManipulated * ValueStack.Pop());
                }
                else
                {
                    if (NumberToBeManipulated == 0)
                    {

                        return false;

                    }
                    else
                    {

                        ValueStack.Push(ValueStack.Pop() / NumberToBeManipulated);

                    }

                }


            }
            else
            {
                ValueStack.Push(NumberToBeManipulated);
            }
            return true;





        }
        /// <summary>
        /// When numbers needs to be added this program takes the integers and adds or subtracts them.
        /// </summary>
        /// <param name="ValueStack"></param>
        /// <param name="OperatorStack"></param>
        public static void DealWithAdditionorSubtraction(Stack<double> ValueStack, Stack<String> OperatorStack)
        {

            if (OperatorStack.IsOnTop("+"))
            {
                OperatorStack.Pop();

                ValueStack.Push(ValueStack.Pop() + ValueStack.Pop());


            }
            else
            {
                OperatorStack.Pop();
                double x = ValueStack.Pop();
                double y = ValueStack.Pop();
                ValueStack.Push(y - x);



            }



        }


        /// <summary>
        /// Enumerates the normalized versions of all of the variables that occur in this 
        /// formula.  No normalization may appear more than once in the enumeration, even 
        /// if it appears more than once in this Formula.
        /// 
        /// For example, if N is a method that converts all the letters in a string to upper case:
        /// 
        /// new Formula("x+y*z", N, s => true).GetVariables() should enumerate "X", "Y", and "Z"
        /// new Formula("x+X*z", N, s => true).GetVariables() should enumerate "X" and "Z".
        /// new Formula("x+X*z").GetVariables() should enumerate "x", "X", and "z".
        /// </summary>
        public IEnumerable<String> GetVariables()
        {
           // uses a hashset to prevent duplication
            HashSet<String> theVariables = new HashSet<String>();
            foreach (string CurrentToken in TokenStorer)
            {
                // uses helper method if the token is a variable adds it to the hashset
                if (IsAValidVariable(CurrentToken))
                {
                    theVariables.Add(CurrentToken);
                }
            }

            return theVariables;

        }

        /// <summary>
        /// Returns a string containing no spaces which, if passed to the Formula
        /// constructor, will produce a Formula f such that this.Equals(f).  All of the
        /// variables in the string should be normalized.
        /// 
        /// For example, if N is a method that converts all the letters in a string to upper case:
        /// 
        /// new Formula("x + y", N, s => true).ToString() should return "X+Y"
        /// new Formula("x + Y").ToString() should return "x+Y"
        /// </summary>
        public override string ToString()
        {
            StringBuilder NewString = new StringBuilder();

            foreach (string CurrentString in TokenStorer)
            {
                if (IsANumber(CurrentString))
                {
                    // if it is a number it manipulates it into a standard form
                    NewString.Append(Double.Parse(CurrentString).ToString());


                }
                else
                {//if it is not a number it does not need to be manipulated
                    NewString.Append(CurrentString);
                }
            }
            return NewString.ToString();
        }

        /// <summary>
        /// If obj is null or obj is not a Formula, returns false.  Otherwise, reports
        /// whether or not this Formula and obj are equal.
        /// 
        /// Two Formulae are considered equal if they consist of the same tokens in the
        /// same order.  To determine token equality, all tokens are compared as strings 
        /// except for numeric tokens and variable tokens.
        /// Numeric tokens are considered equal if they are equal after being "normalized" 
        /// by C#'s standard conversion from string to double, then back to string. This 
        /// eliminates any inconsistencies due to limited floating point precision.
        /// Variable tokens are considered equal if their normalized forms are equal, as 
        /// defined by the provided normalizer.
        /// 
        /// For example, if N is a method that converts all the letters in a string to upper case:
        ///  
        /// new Formula("x1+y2", N, s => true).Equals(new Formula("X1  +  Y2")) is true
        /// new Formula("x1+y2").Equals(new Formula("X1+Y2")) is false
        /// new Formula("x1+y2").Equals(new Formula("y2+x1")) is false
        /// new Formula("2.0 + x7").Equals(new Formula("2.000 + x7")) is true
        /// </summary>
        public override bool Equals(object obj)
        {
            if (obj is Formula && obj != null)
            {
                Formula SecondFormula = (Formula)obj;
                //uses a string in order to standardize it
                return this.ToString().Equals(SecondFormula.ToString());
            }
            //if obj is either null or not a function returns false;
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Reports whether f1 == f2, using the notion of equality from the Equals method.
        /// Note that if both f1 and f2 are null, this method should return true.  If one is
        /// null and one is not, this method should return false.
        /// </summary>
        public static bool operator ==(Formula f1, Formula f2)
        {
            if (f1 is null && f2 is null)
            {
                return true;

            }
            else if (f1 is null && !(f2 is null) || (!(f1 is null) && f2 is null))
            {
                return false;
            }
            else
            {
                return f1.Equals(f2);
            }
        }

        /// <summary>
        /// Reports whether f1 != f2, using the notion of equality from the Equals method.
        /// Note that if both f1 and f2 are null, this method should return false.  If one is
        /// null and one is not, this method should return true.
        /// </summary>
        public static bool operator !=(Formula f1, Formula f2)
        {
            return !(f1 == f2);
        }

        /// <summary>
        /// Returns a hash code for this Formula.  If f1.Equals(f2), then it must be the
        /// case that f1.GetHashCode() == f2.GetHashCode().  Ideally, the probability that two 
        /// randomly-generated unequal Formulae have the same hash code should be extremely small.
        /// </summary>
        public override int GetHashCode()
        {
            // because .ToString is how we determine if two formulas are equal I used the HashCode of the string version of a Formula 
            return this.ToString().GetHashCode();
        }

        /// <summary>
        /// Given an expression, enumerates the tokens that compose it.  Tokens are left paren;
        /// right paren; one of the four operator symbols; a string consisting of a letter or underscore
        /// followed by zero or more letters, digits, or underscores; a double literal; and anything that doesn't
        /// match one of those patterns.  There are no empty tokens, and no token contains white space.
        /// </summary>
        private static IEnumerable<string> GetTokens(String formula)
        {
            // Patterns for individual tokens
            String lpPattern = @"\(";
            String rpPattern = @"\)";
            String opPattern = @"[\+\-*/]";
            String varPattern = @"[a-zA-Z_](?: [a-zA-Z_]|\d)*";
            String doublePattern = @"(?: \d+\.\d* | \d*\.\d+ | \d+ ) (?: [eE][\+-]?\d+)?";
            String spacePattern = @"\s+";

            // Overall pattern
            String pattern = String.Format("({0}) | ({1}) | ({2}) | ({3}) | ({4}) | ({5})",
                                            lpPattern, rpPattern, opPattern, varPattern, doublePattern, spacePattern);

            // Enumerate matching tokens that don't consist solely of white space.
            foreach (String s in Regex.Split(formula, pattern, RegexOptions.IgnorePatternWhitespace))
            {
                if (!Regex.IsMatch(s, @"^\s*$", RegexOptions.Singleline))
                {
                    yield return s;
                }
            }

        }
    }

    /// <summary>
    /// Used to report syntactic errors in the argument to the Formula constructor.
    /// </summary>
    public class FormulaFormatException : Exception
    {
        /// <summary>
        /// Constructs a FormulaFormatException containing the explanatory message.
        /// </summary>
        public FormulaFormatException(String message)
            : base(message)
        {
        }
    }

    /// <summary>
    /// Used as a possible return value of the Formula.Evaluate method.
    /// </summary>
    public struct FormulaError
    {
        /// <summary>
        /// Constructs a FormulaError containing the explanatory reason.
        /// </summary>
        /// <param name="reason"></param>
        public FormulaError(String reason)
            : this()
        {
            Reason = reason;
        }

        /// <summary>
        ///  The reason why this FormulaError was created.
        /// </summary>
        public string Reason { get; private set; }
    }

    static class PS1StackExtensions
    {
        public static bool IsOnTop<T>(this Stack<T> theStack, T Val)
        {
            if (theStack.Count() < 1)
            {
                return false;
            }
            else
            {
                return (theStack.Peek().Equals(Val));
            }

        }
    }



}


﻿//Written by Zachary Gundersen in Response to PS4
//Contains a working class that contains three constructers
//this class is designed to be used with a GUI to form a functional Gui
//The three constructors this class impliments a spreadsheet 
// the empty constructor forms an empty spreadsheet that validates everything that is already standardly
// valid it normalizes input variables to itself and a default version
//
//the second constructor takes a struct that normalizes the string and a struct that validates a variable
//and a version
//
// the last constructure takes the same as second one but an additional string that represents a file
// that takes that file and puts every cell in the file into the spreadsheet


using SpreadsheetUtilities;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Serialization;

namespace SS
{
    /// <summary>
    /// This class creates a spreadsheet object  that can detect cycles and will keep track of non empty cells inside of it along with the dependicies between the cells
    /// Does not contain the implimentation of a GUI
    /// </summary>
    public class Spreadsheet : SS.AbstractSpreadsheet
    {
        // this dictionary is used to keep track of each non empty cell in the spreadsheet
        private Dictionary<string, Cell> NonEmptyCells;
        // this dependency graph is used to keep track of the dependencies between cells.
        private SpreadsheetUtilities.DependencyGraph Dependents;

        public override bool Changed { get; protected set; }

        /// <summary>
        /// creates a SpreadSheetObject that begins empty.
        /// </summary>
        public Spreadsheet() : base(s => true, s => s, "default")

        {

            NonEmptyCells = new Dictionary<string, Cell>();
            Dependents = new DependencyGraph();
            Changed = false; 
            

        }
        public Spreadsheet(Func<string, bool> isValid, Func<string, string> normalize, string version) : base(isValid, normalize, version)
        {
            NonEmptyCells = new Dictionary<string, Cell>();
            Dependents = new DependencyGraph();
            Changed = false;
            

        }
        public Spreadsheet(String theFile, Func<string, bool> isValid, Func<string, string> normalize, string version) : base(isValid, normalize, version)
        {
            NonEmptyCells = new Dictionary<string, Cell>();
            Dependents = new DependencyGraph();
            Changed = false;
            try
            {
                //starts trying to read a file 
                using (XmlReader reader = XmlReader.Create(theFile))
                {
                    //a check to make sure that there is a version used later
                    bool containsAVersion = false;
                  //a string used to store the value of a cells contents until it can be used
                    String contents = "";
                    //a string used to store the value of a cells name until it can be used
                    String name = "";
                    while (reader.Read())
                    {
                        
                        if (reader.IsStartElement())
                        {
                            //switch statements check that the  elements of the cell
                            switch (reader.Name)
                            {

                                case "spreadsheet":
                                    // when encontering a spread sheet checks that it Version matches.
                                    if (reader["version"] == Version)
                                    {
                                        containsAVersion = true;
                                    }
                                    else
                                    {// if it's version doesn't match it throws an exception 
                                        throw new SpreadsheetReadWriteException("The version in the file and the spreadsheet's version do not match");
                                    }
                                    break; // no more direct info to read on Spreadsheey
                                case "cell":
                                    break; // no more direct info to read cells

                                case "name":
                                    // when it is a name it gets its value i
                                    reader.Read();
                                    name = reader.Value;
                                    break;
                                case "contents":
                                    // it gets the value of contents
                                    reader.Read();
                                    contents = reader.Value;
                                    break;

                                default:
                                    // if the element is not one of the standard for a spreadsheet throws an error
                                    throw new SpreadsheetReadWriteException("There is an unknown element inside the file");
                                    
                            
                                
                            }

                            


                            


                        }
                        else
                        {// if it isn't a starting element it is an ending 
                            if(reader.Name == "cell")
                            {
                                //checks if either the contents or the name hasn't been assigned and if it hasn't then throw an error
                                if(contents != "" && name != "")
                                {
                                    this.SetContentsOfCell(name, contents);
                                    contents = "";
                                    name = "";
                                }
                                else
                                {
                                    throw new SpreadsheetReadWriteException("this file contains an cell without either a name or contents or possibly both");
                                }
                            }
                        }


                    }
                    //if a version hasn't been assigned that means there hasn't been a spreadsheet element which is wrong so through an error
                    if (!containsAVersion)
                    {
                        throw new SpreadsheetReadWriteException("this file does not contain a spreadsheet");
                    }

                }
            }
            catch(SpreadsheetReadWriteException ex)
            {
                throw ex;
            }
            // if a cell would result in a circular exception through
            catch (CircularException)
            {
                throw new SpreadsheetReadWriteException("There was a a cell in the file that caused a cicle leading to an invalid spreadsheet.");
            }
            catch (FormulaFormatException)
            {
                //if a cell would try to form a formula that is invalid formula 
                throw new SpreadsheetReadWriteException("There is a formula with invalid formatting in the file causing it to fail.");
            }
            catch 
            {// catches the rest of the errors if the file has any problems
                throw new SpreadsheetReadWriteException("There is an error in the file of the spreadsheet causing it to fail.");
            }

            Changed = false;
        }
        public override IEnumerable<string> GetNamesOfAllNonemptyCells()
        {
            return NonEmptyCells.Keys;
        }

        public override object GetCellContents(string name)
        {
            name = Normalize(name);
            if (name == null || !IsValidForThisSpreasheet(name))
            {
                throw new InvalidNameException();
            }

            if (NonEmptyCells.TryGetValue(name, out Cell theCell))
            {
                return theCell.GetContents();
            }
            else
            {
                // if the cell is not in the nonempty cells that means it is an empty cell and it returns an empty string
                return "";
            }

        }


        protected override IList<string> SetCellContents(string name, double number)
        {




            if (NonEmptyCells.ContainsKey(name))
            {
                // if this cell had previously had a different contents it is possible that 
                // it has dependencees that are no longer valid therefor we put an empty set in its place to empty the no longer valid dependency groups

                HashSet<String> emptySet = new HashSet<string>();
                Dependents.ReplaceDependees(name, emptySet);
                NonEmptyCells[name] = new Cell(name, number);
            }
            else
            {
                // if it did not have a value originally then it can not have a dependency therefor it is ok to just add the cell 
                NonEmptyCells.Add(name, new Cell(name, number));
            }
            Changed = true;
            foreach (String s in GetCellsToRecalculate(name).ToList())
            {
                NonEmptyCells[s].SetValue(Lookup);
            }
            return GetCellsToRecalculate(name).ToList();

        }

        protected override IList<string> SetCellContents(string name, string text)
        {
           
           


                if (NonEmptyCells.ContainsKey(name))
                {
                    // if this cell had previously had a different contents it is possible that 
                    // it has dependencees that are no longer valid therefor we put an empty set in its place to empty the no longer valid dependency groups

                    HashSet<String> emptySet = new HashSet<string>();
                    Dependents.ReplaceDependees(name, emptySet);
                    NonEmptyCells[name] = new Cell(name, text);

                }
                else
                {
                    // if it did not have a value originally then it can not have a dependency therefor it is ok to just add the cell 
                    NonEmptyCells.Add(name, new Cell(name, text));
                }


            
            Changed = true;
            foreach (String s in GetCellsToRecalculate(name).ToList())
            {
                NonEmptyCells[s].SetValue(Lookup);
            }
            return GetCellsToRecalculate(name).ToList();
        }

        /// <summary>
        /// Behaves similarly to the other versions of SetCellContents, but instead takes a Function object to store as its contents
        /// </summary>
        /// <param name="name"></param>
        /// <param name="function"></param>
        /// <returns></returns>
        protected IList<string> SetCellContents(string name, Function function)
        {
            // stores the previous dependees in case we need to revert the graph to where it was before modification
            HashSet<String> OldDependees = new HashSet<String>((HashSet<String>)Dependents.GetDependees(name));

            try
            {
                Dependents.ReplaceDependees(name, function.GetVariables());
                GetCellsToRecalculate(name);
            }
            catch (CircularException ex)
            {
                // put the old dependees back becuase we are not going to add the 
                // new cell to the graph because it would cause a cycle
                // this removes the bad dependecy groups
                Dependents.ReplaceDependees(name, OldDependees);
                throw ex;
            }

            Changed = true;

            // now that we know that the addition didn't cause a cycle we can add the cell to the graph
            if (NonEmptyCells.ContainsKey(name))
            {
                // because we already replaced the dependency groups we do not need to do it here like in the other methods
                NonEmptyCells[name] = new Cell(name, function);
            }
            else
            {
                NonEmptyCells.Add(name, new Cell(name, function));
            }
            foreach (String s in GetCellsToRecalculate(name).ToList())
            {
                NonEmptyCells[s].SetValue(Lookup);
            }
            return GetCellsToRecalculate(name).ToList(); //returns the list of all cells that need to be recalculated, including this cell
        }

        protected override IList<string> SetCellContents(string name, Formula formula)
        {
          
                // stores the previous dependees in case we need to revert the graph to where it was before modification
                HashSet<String> OldDependees = new HashSet<String>((HashSet<String>)Dependents.GetDependees(name));





                try
                {
                    // as it does not know if the new cell will cause a cycle it does not change the dictionary containing the cells
                    // however GetCellsToREcalculate depends on the DependencyGraph being up to date as if the Cell has been added
                    // therefore we add the dependencys
                    Dependents.ReplaceDependees(name, formula.GetVariables());
                    GetCellsToRecalculate(name).ToList();
                }
                catch (CircularException ex)
                {
                    // put the old dependees back becuase we are not going to add the 
                    // new cell to the graph because it would cause a cycle
                    // this removes the bad dependecy groups
                    Dependents.ReplaceDependees(name, OldDependees);
                    throw ex;

                }
                Changed = true;
            
            // now that we know that the addition didn't cause a cycle we can add the cell to the graph
            if (NonEmptyCells.ContainsKey(name))
                {
                    // because we already replaced the dependency groups we do not need to do it here like in the other methods
                    NonEmptyCells[name] = new Cell(name, formula);
                }
                else
                {
                    NonEmptyCells.Add(name, new Cell(name, formula));
                }
            foreach (String s in GetCellsToRecalculate(name).ToList())
            {
                NonEmptyCells[s].SetValue(Lookup);
            }
            return GetCellsToRecalculate(name).ToList();


            
        }



        protected override IEnumerable<string> GetDirectDependents(string name)
        {
            return Dependents.GetDependents(name);
        }
        /// <summary>
        /// This checks if a variable is both valid for a standard pattern and the pattern imported by the user
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        private bool IsValidForThisSpreasheet(string s)
        {
            s = Normalize(s);
            String varPattern = "^[a-zA-Z]+[0-9]+$";
            //checks if it is valid in general
            if (Regex.IsMatch(s, varPattern))
            {
                //if it matches the first pattern tests if it matches the second pattern
                if (IsValid(s))
                {
                    return true;
                }
                else
                {
                    return false;
                }
                

            }
            else
            {
                return false;
            }

        }

        public override string GetSavedVersion(string filename)
        {
            try { 
            using (XmlReader reader = XmlReader.Create(filename))
            {
                    while (reader.Read())
                    {
                        if (reader.IsStartElement())
                        {
                            switch (reader.Name)
                            {

                                case "spreadsheet":
                                    // when encontering a spread sheet checks that it Version matches.
                                    if (reader["version"] == null)
                                    {
                                        //Dpesn't do anything here so it will later throw a exception
                                    }
                                    else
                                    {
                                        return reader["version"];
                                    }
                                   
                                    break; // no more direct info to read on Spreadsheey
                                case "cell":
                                    break; // no more direct info to read cells

                                case "name":
                                    
                                    break;
                                case "contents":
                                    
                                    
                                    break;

                                default:
                                    // if the element is not one of the standard for a spreadsheet throws an error
                                    throw new SpreadsheetReadWriteException("There is an unknown element inside the file");



                            }
                           
                        }

                    }
                    // if it gets to this point then there is no version so through an error
                    throw new SpreadsheetReadWriteException("");

            } 
            }
            catch
            {
                throw new SpreadsheetReadWriteException("the file encountered a problem");
            }
           
        }
       
        public override void Save(string filename)
        {
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.IndentChars = "   ";
            // use xml to write a file that is in the standard set up of a spreadsheet file
            try
            {
                using (XmlWriter writer = XmlWriter.Create(filename, settings))
                {
                    writer.WriteStartDocument();
                    // writes a element for the spreadsheet
                    writer.WriteStartElement("spreadsheet");
                    // makes the version an attribute
                    writer.WriteAttributeString("version", Version);
                    foreach (String CellName in GetNamesOfAllNonemptyCells())
                    {
                        // writes a cell for each cell in the SpreadSheet
                        writer.WriteStartElement("cell");
                        //records the name in the spreadsheet
                        writer.WriteElementString("name", CellName);
                        try
                        {
                            /// tries to check if the contents is a formula if it is it creates a string that properly represents a formula
                            Formula f = (Formula)NonEmptyCells[CellName].GetContents();
                            writer.WriteElementString("contents", "=" + f.ToString());
                        }
                        catch
                        {
                            //if it wasn't a formula then it will come here and right the contents as a string
                            writer.WriteElementString("contents", NonEmptyCells[CellName].GetContents().ToString());

                        }

                        writer.WriteEndElement();
                    }
                    writer.WriteEndElement();

                    writer.WriteEndDocument();
                }
            }
            catch 
            {
                throw new SpreadsheetReadWriteException("this file had trouble saving the given file name is probably the problem");
            }
            // resests the changed status because it was just saved
            Changed = false;
        }

        public override object GetCellValue(string name)
        {
           // if the name is null throw error
            if(name == null)
            {
                throw new InvalidNameException();
            }
            // normalize name and then check if it is valid if not throw error
            name = Normalize(name);
         
             if (!IsValidForThisSpreasheet(name))
            {
                throw new InvalidNameException();
            }
            else if (!NonEmptyCells.ContainsKey(name))
            {
                // if the cell has not been assigned yet the cell is empty and its value should be empty
                return "";
            }

            return NonEmptyCells[name].GetValue();
        }

        //This one is done
        public override IList<string> SetContentsOfCell(string name, string content)
        {
            if(name == null)
            {
                throw new InvalidNameException();
            }
            name = Normalize(name);
            if (content == null)
            {
                throw new ArgumentNullException();
            }
            if (!IsValidForThisSpreasheet(name))
            {
                throw new InvalidNameException();
            }
            else if(content == "")
            {
                return SetCellContents(name, "");
            }
            else if (Double.TryParse(content, out double result))
            {
               
                return SetCellContents(name, result);


            }
            else if (content.ElementAt<char>(0) == '=')
            {
                if (Function.IsFunction(content))
                {
                    return SetCellContents(name, new Function(content, Lookup));
                }

                return SetCellContents(name, new Formula(content.Substring(1, content.Length - 1), Normalize, IsValidForThisSpreasheet));
            }
            else
            {
               
                return SetCellContents(name, content);
            }


        }

        //This one is done
        public bool ContentsCheck(string name, string content)
        {
            if (name == null)
            {
                throw new InvalidNameException();
            }
            name = Normalize(name);
            if (content == null)
            {
                return false;
            }
            if (!IsValidForThisSpreasheet(name))
            {
                return false;
            }
            else if (content == "")
            {
                return true;
            }
            else if (Double.TryParse(content, out double result))
            {

                return true;


            }
            else if (content.ElementAt<char>(0) == '=')
            {
                if (Function.IsFunction(content))
                {
                    return true;
                }

                return true;
            }
            else
            {

                return false;
            }


        }

        private double Lookup(string s)
        {
            try
            {
                return (double)NonEmptyCells[s].GetValue();
            }
            catch
            {
                throw new ArgumentException();
            }
        }
        /// <summary>
        /// this creates a Cell object that is used in the Spreadsheet to represent one single cell.
        /// </summary>
        public class Cell
        {
            //The name of the Cell 
            private string name;
            // the contents of the cell a string or a double or a Formula.
            private object contents;
            private object value;

            /// <summary>
            /// sets up the cell placing its name and contents
            /// </summary>
            /// <param name="name"></param>
            /// <param name="contents"></param>
            public Cell(String name, object contents)
            {
                this.name = name;
                this.contents = contents;
                

            }



            /// <summary>
            ///  returns the contents of the cell for use;
            /// </summary>
            /// <returns></returns>
            public object GetContents()
            {
                return contents;
            }


            public void SetValue(Func<string, double> Lookup)
            {
                
                try
                {
                    Function tempFunc = (Function)contents;
                    value = tempFunc.Evaluate();
                    return;
                }
                catch (Exception)
                {

                }

                try
                {
                    Formula tempFormula = (Formula)contents;
                    value = tempFormula.Evaluate(Lookup);
                }
                catch
                {
                    //part of Easter Egg!
                    if (contents.ToString() == "JD" && name == "J4")
                    {
                        value = "Halfway!";
                    }
                    else if (contents.ToString() == "ZG" && name == "Z7")
                    {
                        value = "Getting there!";
                    }
                    else if (contents.ToString() == "JD" || contents.ToString() == "ZG")
                    {
                        value = "Not quite";
                    }
                    else
                        value = contents;
                }
            }


            public object GetValue()
            {
                return value;
            }

        }

    }
}

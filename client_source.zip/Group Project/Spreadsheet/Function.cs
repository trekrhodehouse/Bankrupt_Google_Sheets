﻿/*Function class was created 10/08/2020
 * Contains a working class that creates an object which stores the variables which it contains as well as its contents string and a Evaluator that returns a double or its contents string
 * 10/9/2020 changed functionality so that it ignores variables that are empty rather than returning a function error
*/


using SpreadsheetUtilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace SpreadsheetUtilities
{
    /// <summary>
    /// A Function object represents a set of variables that are manipulated according to which function was passed in the five current options are sum avg(average) min max and count 
    /// the string passed in is only valid if it follows the strict pattern of ="functiontype"("Cell1", "Cell2") and then when it has created the object it stores using a Formula the range of cells that it is dependent on 
    /// and it stores a contents which is the string that was passed in 
    /// it has three public methods that let you get the dependent variables it also lets you get the contents out and it has an evaluate method that returns the current value of the function
    /// </summary>
    public class Function
    {
        // creates a formula that is used to access its get variables methods
        private Formula formula;
        // acceptable strings that can be used for creating a useful Function
        readonly static string sumP = @"^=SUM\([A-Z][0-9]{1,2},(| )[A-Z][0-9]{1,2}\)$", avgP = @"^=AVG\([A-Z][0-9]{1,2},(| )[A-Z][0-9]{1,2}\)$", maxP = @"^=MAX\([A-Z][0-9]{1,2},(| )[A-Z][0-9]{1,2}\)$", minP = @"^=MIN\([A-Z][0-9]{1,2},(| )[A-Z][0-9]{1,2}\)$", countP = @"^=COUNT\([A-Z][0-9]{1,2},(| )[A-Z][0-9]{1,2}\)$";
      // a list that stores the above patterns
        static private List<string> patterns = new List<string>();
        // a func that stores the input look up method that determines the value of a variable
        private Func<string, double> Lookup;
        // the values of the part of the string that represents variables
        private string var1, var2;
        // a string that keeps the part of the string in the input that represents the specific action
        private string operation;

        /// <summary>
        /// gets a public Contents that allows the user to see what the contents are but not to set it
        /// </summary>
        public string Contents
        {
            get; protected set;
        }
        /// <summary>
        /// Sets up a function object that has a contents and a formula for storing variables 
        /// sets the lookup function to the one given by the user
        /// 
        /// </summary>
        /// <param name="contents"></param>
        /// <param name="lookup"></param>
        public Function(string contents, Func<string, double> lookup)
        {
            // list of patterns that are acceptable for use
            patterns.Add(sumP);
            patterns.Add(avgP);
            patterns.Add(maxP);
            patterns.Add(minP);
            patterns.Add(countP);
            // standerdizes the contents to uppercase
            Contents = contents.ToUpper();
            Lookup = lookup;

            //if this is not a valid function it throws an error
            if (!IsFunction())
            {
                throw new FunctionFormatException("This, is not a valid function");
            }

            int TypeOfCellDirection;
            // checks if the cells are in a line and returns the type of cell configuration if it is
            // cell configuration allows us to know how to itterate through the cells to find the range
            if (!ValidateCellRange(out TypeOfCellDirection))
            {
                throw new FunctionFormatException("Incorrect cell range; cell range must be continuous in one column or one row.");
            }

            //this gets the type of operation
            operation = contents.Substring(1, 3).ToUpper();

            string result = "";
            //depending on the case it sets up the the correct result
            // the result will be used in setting up the function
            switch (operation)
            {
                case "SUM":
                    result = Sum(TypeOfCellDirection, true);
                    break;
                case "AVG":
                    result = Avg(TypeOfCellDirection, true);
                    break;
                case "MAX":
                    result = Max(TypeOfCellDirection, out string s1);
                    break;
                case "MIN":
                    result = Min(TypeOfCellDirection, out string s2);
                    break;
                case "COU":
                    result = Count(TypeOfCellDirection, true);
                    break;
                
            }
            // sets the formulathat keeps track of dependencies
            formula = new Formula(result);

        }

        /// <summary>
        /// gets the cells that are inside the range of the function
        /// </summary>
        /// <returns></returns>
        public IEnumerable<String> GetVariables()
        {
            return formula.GetVariables();
        }

        /// <summary>
        /// evaluates returns the current sum of the contents 
        /// this changes because every function only returns the non empty cells in the range and then is stored in a new formula that evaluates the formula given to produce the correct result
        /// </summary>
        /// <returns></returns>
        public object Evaluate()
        {
            object eval;
            // gets the correct path of two itterate;
            ValidateCellRange(out int DirectionofIteration);

            if (operation == "SUM" ) {
                // if its a sum stores the sum formula string into a formula and then evalutes the formula producing the correct result
                Formula tempformula = new Formula(Sum(DirectionofIteration, false));
                eval = tempformula.Evaluate(Lookup);
              
            }
            else if(operation == "AVG")
            {
                //same thing as sum
               Formula tempformula = new Formula(Avg(DirectionofIteration, false));
                eval = tempformula.Evaluate(Lookup);
            }
            else if (operation == "MAX")
            {
                //Max returns the contents of the range and its value is the max in that range
                Max(DirectionofIteration, out string val);
                // storing it inside the Formula and then evaluating it makes sure that it will be properly updated
                Formula tempformula = new Formula(val);
                //if the value is still the minValue that means that there is nothing in the cells that have a double value so it shows this by returning contents
                if(double.Parse(val) == double.MinValue)
                {
                    return Contents;
                }
                eval = tempformula.Evaluate(Lookup);
            }
            else if (operation == "MIN")
            {
                //same thing as max but in the other direction
                Min(DirectionofIteration, out string val) ;
                Formula tempformula = new Formula(val);
                if (double.Parse(val) == double.MaxValue)
                {
                    return Contents;
                }
              
                eval = tempformula.Evaluate(Lookup);
            }
            else
            {
                // if it is none of the above functions then it is Count and it returns a number that is then stored into a Formula 
                // then gets the formula Evaluate to get the correct number that updates. 
                Formula tempformula = new Formula(Count(DirectionofIteration, false));
                eval = tempformula.Evaluate(Lookup);
               
            }
            // returns the value that was collected inside the if else statements
            return eval;
        }

        /// <summary>
        /// the start is the starting variable that we use to work toward the other variable.
        /// the first time bool allows this function to know if it wants every variable into the permenant function or just the variables that have contents that are equivalent to a double
        /// this method is activated when the start and finish string have same letter but different numbers such as A1 and A5
        /// </summary>
        /// <param name="start"></param>
        /// <param name="finish"></param>
        /// <param name="FirstTime"></param>
        /// <returns></returns>
        private List<string> VariableNumberDefiner(string start, string finish, bool FirstTime)
        {
           
            List<string> list = new List<string>();
            if (FirstTime)
            {
                // if its the first time it itterates and adds every elements
                for (int i = int.Parse(start.Substring(1)); i <= int.Parse(finish.Substring(1)); i++)
                {
                    list.Add("" + start.ElementAt(0) + i);
                }
            }
            else
            {
                //if it is not the first time we want only the bariables that look up allows if Lookup throws then we do not add.
                for (int i = int.Parse(start.Substring(1)); i <= int.Parse(finish.Substring(1)); i++)
                {
                    try
                    {
                        Lookup("" + start.ElementAt(0) + i);
                        list.Add("" + start.ElementAt(0) + i);
                    }
                    catch
                    {

                    }
                }

                
            }

            return list;
        }
        /// <summary>
        /// the start is the starting variable that we use to work toward the other variable.
        /// the first time bool allows this function to know if it wants every variable into the permenant function or just the variables that have contents that are equivalent to a double
        /// this method is activated when the start and finish string have different letters but the numbers such as A44 and C44
        /// </summary>
        /// <param name="start"></param>
        /// <param name="finish"></param>
        /// <param name="FirstTime"></param>
        /// <returns></returns>
        private List<string> VariableLetterDefiner(string start, string finish, bool FirstTime)
        {
            List<string> list = new List<string>();
            if (FirstTime)
            {// if it is the first time that means we want every variable to be added to keep track of what the function depends on
                for (char letter = start.ElementAt(0); letter <= finish.ElementAt(0); letter++)
                {
                    list.Add("" + letter + start.Substring(1));
                }
            }
            else
            {
                // if it isn't the first time we want only the ones the lookup can return a double for
                for (char letter = start.ElementAt(0); letter <= finish.ElementAt(0); letter++)
                {
                    try
                    {
                        Lookup("" + letter + start.Substring(1));
                        list.Add("" + letter + start.Substring(1));
                    }
                    catch
                    {

                    }

                }
            }
            return list;
        }

        /// <summary>
        /// generates a string from a list that adds all the strings to the list with a space inbetween
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>

        private string GenerateFormulaSum(List<string> list)
        {
            StringBuilder s = new StringBuilder();
            s.Append(list[0]);

            for (int i = 1; i < list.Count; i++)
            {
                s.Append("+" + list[i]);
            }

            return s.ToString();
        }

        /// <summary>
        /// Gets the string that when put into a formula will generate the sum 
        /// the firsttime parameter is used to tell the VariableNumberDefiner if we want every variable or only the ones with contents that are able to be represented as a double
        /// </summary>
        /// <param name="x"></param>
        /// <param name="firstTime"></param>
        /// <returns></returns>
        private string Sum(int x, bool firstTime)
        {
            string s = "";
            switch(x)
            {
                //the cases represent how the two variables that were input are related
                //and makes sure that the correct methods are used.
                case 1:
                    s = GenerateFormulaSum(VariableNumberDefiner(var1, var2, firstTime));
                    break;
                case 2:
                    s = GenerateFormulaSum(VariableNumberDefiner(var2, var1, firstTime));
                    break;
                case 3:
                    s = GenerateFormulaSum(VariableLetterDefiner(var1, var2, firstTime));
                    break;
                case 4:
                    s = GenerateFormulaSum(VariableLetterDefiner(var2, var1, firstTime));
                    break;
            }
            //returns the string that represents the formula for finding sum
            return s;
        }
        /// <summary>
        /// gets the string that represents the equation of getting the average for the range of cells
        /// </summary>
        /// <param name="x"></param>
        /// <param name="firstTime"></param>
        /// <returns></returns>
        private string Avg(int x, bool firstTime)
        {
            // uses the sum and the count methods to get the correct formulas
            return ("(" + Sum(x, firstTime) + ")/" + Count(x, firstTime));
        }
        /// <summary>
        /// This method gets the string representation of
        /// the maximum value and returns the list of cells that it had to consider
        /// </summary>
        /// <param name="x"></param>
        /// <param name="max"></param>
        /// <returns></returns>
        private string Max(int x, out string max )
        {
            List<string> list;
            switch (x)
            {
                //goes through and gets a list of variables that need to be considered
                case 1:
                    list = VariableNumberDefiner(var1, var2, true);
                    break;
                case 2:
                    list = VariableNumberDefiner(var2, var1, true);
                    break;
                case 3:
                    list = VariableLetterDefiner(var1, var2, true);
                    break;
                case 4:
                    list = VariableLetterDefiner(var2, var1, true);
                    break;
                default:
                    list = new List<string>();
                    break;
            }

            double maxVal;
            //sets the maxval as the minimum possible in order to see if there were any changes to its value
            maxVal = double.MinValue;
            foreach (string var in list)
            {
                try
                {
                    // if lookup var returns a double and it is greater than the current max val we replace it 
                    if (maxVal < Lookup(var))
                        maxVal = Lookup(var);

                }
                catch (Exception)
                {
                }
            }
            // we return maxval as a string to keep it compatible with the function
            max = maxVal.ToString();
            return Sum(x, true);
        }
        /// <summary>
        /// This method gets the string representation of
        /// the maximum value and returns the list of cells that it had to consider
        /// </summary>
        /// <param name="x"></param>
        /// <param name="min"></param>
        /// <returns></returns>
        private string Min(int x, out string min)
        {
            List<string> list;
            switch (x)
            {//goes through and gets a list of variables that need to be considered
                case 1:
                    list = VariableNumberDefiner(var1, var2, true);
                    break;
                case 2:
                    list = VariableNumberDefiner(var2, var1, true);
                    break;
                case 3:
                    list = VariableLetterDefiner(var1, var2, true);
                    break;
                case 4:
                    list = VariableLetterDefiner(var2, var1, true);
                    break;
                default:
                    list = new List<string>();
                    break;
            }

            double minVal;
            //sets the minval as the maximum possible in order to see if there were any changes to its value
            minVal = double.MaxValue;
            foreach (string var in list)
            {
                try
                {
                    // if lookup var returns a double and it is less than the current min val we replace it 
                    if (minVal > Lookup(var))
                        minVal = Lookup(var);

                }
                catch (Exception)
                {
                }
            }
            //returns the minimum value as a string so that it is compatable with the formula method that we use to keep updating the sum
            min = minVal.ToString();
            return Sum(x, true);
        }
        /// <summary>
        /// returns a string representing a number that is the number of cells that are filled 
        /// </summary>
        /// <param name="x"></param>
        /// <param name="FirstTime"></param>
        /// <returns></returns>
        private string Count(int x, bool FirstTime)
        {
            int ct = 0;

            switch (x)
            {
                // goes through the method that returns the list of filled cells and checks how many there are
                case 1:
                    ct = VariableNumberDefiner(var1, var2, FirstTime).Count;
                    break;
                case 2:
                    ct = VariableNumberDefiner(var2, var1, FirstTime).Count;
                    break;
                case 3:
                    ct = VariableLetterDefiner(var1, var2, FirstTime).Count;
                    break;
                case 4:
                    ct = VariableLetterDefiner(var2, var1, FirstTime).Count;
                    break;
            }
            //returns the number as a to string as we are using a formula to enforce that the count is always updated
            return ct.ToString();
        }


        /// <summary>
        /// Validates a cell range. A cell range must be contained entirely within either one column or one row.
        /// </summary>
        /// <param name="x">Indicates the direction of the range: left-right(1), right-left(2), top-down(3), bottom-up(4)</param>
        /// <returns></returns>
        private bool ValidateCellRange(out int x)
        {
            //unnecessarily complicated way of getting the two cells from within the function that indicate the range - start and stop
            string[] vars = Contents.Substring(Contents.IndexOf('(') + 1, Contents.Length -  1 - (Contents.IndexOf('(') + 1)).Split(',');
            //trims the cells, ignoring whitespace
            for (int i = 0; i < vars.Length; i++)
            {
                vars[i] = vars[i].Trim();
            }
            //sets class members for later reference
            var1 = vars[0];
            var2 = vars[1];
            //if the letter of both cells is the same, column - (A2, A24) - returns true
            if (vars[0].ElementAt(0) == vars[1].ElementAt(0))
            {
                //determine the direction of the range of cells - (A12, A14) vs (A45, A2)
                int num1 = int.Parse(vars[0].Substring(1)), num2 = int.Parse(vars[1].Substring(1)); 
                if (num1 < num2)
                    x = 1;
                else
                    x = 2;
                return true;
            }
            //if the number of both cells is the same, row - (A2, D2) - returns true
            if (vars[0].Substring(1) == vars[1].Substring(1))
            {
                if (vars[0].ElementAt(0) < vars[1].ElementAt(0)) //dermines the direction of the range of cells - (A12, D12) vs (D12, A12)
                    x = 3;
                else
                    x = 4;
                return true;
            }
            //For x: because we use an out parameter, must assign some value before every return path. Did it here, rather than at the beginning of the method.
            //This value will never be used, because we are only interested in the boolean return value
            x = -1;
            return false;
        }

        /// <summary>
        /// Instance function that allows validation of an instantiated Function object
        /// </summary>
        /// <returns></returns>
        private bool IsFunction()
        {
            foreach (string pat in patterns)
            {
                if (Regex.IsMatch(Contents, pat))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// This static method allows remote checking from the spreadsheet to validate whether a function is a valid function,
        /// so we do not have to instantiate a Function first to validate it.
        /// </summary>
        /// <param name="f"></param>
        /// <returns></returns>
        public static bool IsFunction(string f)
        {
            patterns.Add(sumP); //not sure if this part is necessary, but how else do we initialize a static list we need without creating a Functio object?
            patterns.Add(avgP);
            patterns.Add(maxP);
            patterns.Add(minP);
            patterns.Add(countP);

            string fU = f.ToUpper();
            foreach (string pat in patterns)
            {
                if (Regex.IsMatch(fU, pat))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Overrides ToString(). Any invoking of the ToString() will return the contents of the Cell, rather than the value.
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return Contents;
        }

    }

    /// <summary>
    /// Designed to replicate the FormulaFormatException class to be used similarly
    /// </summary>
    public class FunctionFormatException : Exception
    {
        public FunctionFormatException(String msg) : base(msg) { }
    }



    /// <summary>
    /// Used as a possible return value of the Formula.Evaluate method.
    /// </summary>
    public struct FunctionError
    {
        /// <summary>
        /// Constructs a FormulaError containing the explanatory reason.
        /// </summary>
        /// <param name="reason"></param>
        public FunctionError(String reason)
            : this()
        {
            Reason = reason;
        }

        /// <summary>
        ///  The reason why this FormulaError was created.
        /// </summary>
        public string Reason { get; private set; }
    }

}

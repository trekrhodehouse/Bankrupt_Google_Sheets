﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace SS
{
    [JsonObject(MemberSerialization.OptIn)]
    public class CellServerUpdate
    {
        [JsonProperty(PropertyName = "messageType")]
        private string type;

        [JsonProperty(PropertyName = "cellName")]
        private string name;

        [JsonProperty(PropertyName = "contents")]
        private string contents;

        public CellServerUpdate(string requestType, string cellName, string cellContents)
        {
            type = requestType;
            name = cellName;
            contents = cellContents;
        }

        public string getType()
        {
            return type;
        }

        public string getName()
        {
            return name;
        }

        public string getContents()
        {
            return contents;
        }
    }
}

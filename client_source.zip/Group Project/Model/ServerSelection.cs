﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace SS
{
    [JsonObject(MemberSerialization.OptIn)]
    public class ServerSelection
    {
        [JsonProperty(PropertyName = "messageType")]
        private string type;

        [JsonProperty(PropertyName = "cellName")]
        private string nameOfCell;

        [JsonProperty(PropertyName = "selector")]
        private int ID;

        [JsonProperty(PropertyName = "selectorName")]
        private string nameOfSelector;

        public ServerSelection(string requestType, string cellName, int selector, string selectorName)
        {
            type = requestType;
            nameOfCell = cellName;
            ID = selector;
            nameOfSelector = selectorName;
        }

        public string getType()
        {
            return type;
        }

        public string getCellName()
        {
            return nameOfCell;
        }

        public int getSelectorID()
        {
            return ID;
        }

        public string getSelectorName()
        {
            return nameOfSelector;
        }
    }
}

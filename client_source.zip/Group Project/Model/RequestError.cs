﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace SS
{
    [JsonObject(MemberSerialization.OptIn)]
    public class RequestError
    {
        [JsonProperty(PropertyName = "messageType")]
        private string type;

        [JsonProperty(PropertyName = "cellName")]
        private string name;

        [JsonProperty(PropertyName = "message")]
        private string message;

        public RequestError(string requestType, string cellName, string errorMessage)
        {
            type = requestType;
            name = cellName;
            message = errorMessage;
        }

        public string getType()
        {
            return type;
        }

        public string getName()
        {
            return name;
        }

        public string getMessage()
        {
            return message;
        }
    }
}


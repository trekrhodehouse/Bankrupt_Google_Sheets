﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace SS
{
    [JsonObject(MemberSerialization.OptIn)]
    public class ServerDisconnect
    {
        [JsonProperty(PropertyName = "messageType")]
        private string type;

        [JsonProperty(PropertyName = "user")]
        private int ID;

        public ServerDisconnect(string requestType, int selector)
        {
            type = requestType;
            ID = selector;
        }

        public string getType()
        {
            return type;
        }

        public int getSelectorID()
        {
            return ID;
        }
    }
}

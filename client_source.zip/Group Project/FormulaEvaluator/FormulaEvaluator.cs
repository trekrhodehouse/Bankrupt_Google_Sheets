﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;

namespace FormulaEvaluator
{
    static class PS1StackExtensions 
    { 
    public static bool IsOnTop<T> (this Stack<T> theStack, T Val)
        {
            if (theStack.Count() < 1 ){
                return false;
            }
            else
            {
                return (theStack.Peek().Equals(Val));
            }
            
        }
    }


    public static class Evaluator
    {
        public delegate Double Lookup(String v);

      /// <summary>
      /// This class takes a string that represents an expression and find the value as a number
      /// </summary>
      /// <param name="ex"></param>
      /// <param name="variableEvaluator"></param>
      /// <returns></returns>
        public static Double Evaluate(string ex, Lookup variableEvaluator)
        {
            Stack<String> OperatorStack = new Stack<String>();
            Stack<Double> ValueStack = new Stack<Double>();
         
           
            string[] substrings = System.Text.RegularExpressions.Regex.Split(ex, "(\\()|(\\))|(-)|(\\+)|(\\*)|(/)");
            // Splits string
          
            //Trims all leading and trailing white space from each token
            for (int i = 0; i < substrings.Length; i++)
            {
                substrings[i] = substrings[i].Trim();

            }
            
            //goes through all tokens to evaluate 
            foreach (string s in substrings)
            {
                // dismisses any empty strings. 
                if (s.Trim().Equals(""))
                {
                    continue;
                }
                double NewInt;
                // determins if the token is one of the three that only needs to be pushed into the stack, 
                if (s.Equals("(") || s.Equals("*") || s.Equals("/"))
                {

                    OperatorStack.Push(s);
                    continue;
                }
                // proccesses when the next token is an ) 
                else if (s.Equals(")"))
                {
                   
                    string t = OperatorStack.Peek();
                   
                    switch (t)
                    {

                        

                        
                        case ("-"):
                        case ("+"):
                            DealWithAdditionorSubtraction( ValueStack, OperatorStack);
                           
                           

                            break;

                    }
                    // Once the addition or subtraction inside a parethesis is complete make sure that there was a ( symbol to make syntactic sense
                    if (!OperatorStack.IsOnTop("("))
                        { 
                        throw new ArgumentException();
                    }
                    else
                    {
                        OperatorStack.Pop();
                        //Checks if the parenthesis were proceeded by a * or a /
                        if (OperatorStack.Count() > 0)
                        {
                            DealWithMultiplicationorDivisionWithParenthesis(ValueStack, OperatorStack);
                        }
                    }
                    

                    continue;
                }
                // Uses a helper method to complete any + or - if needed then pushes the new token onto the  operatorstack
                else if (s.Equals("+") || s.Equals("-"))
                {
                    if (OperatorStack.Count != 0)
                    {
                        if (OperatorStack.IsOnTop("+") || OperatorStack.IsOnTop("-"))
                        {
                            DealWithAdditionorSubtraction( ValueStack, OperatorStack);
                            
                        }
                       
                    }
                    OperatorStack.Push(s);
                   
                    continue;
                }


                // checks if the token is a integer if it is uses a helper method to deal with it. 
                else if (double.TryParse(s, out NewInt))
                {
                    DealWithDouble(NewInt, ValueStack, OperatorStack);

                }
                else
                {
                    // finally checks if the token is a variable according to the rules, if not throws an error. 
                    //if it is it converts into a integer or throws an error if the variable is not representing an error 
                    //once an integer it uses the same method as a normal integer to decide what to do.
                    string pattern = "^[a-zA-Z]+[0-9]+$";
                   if ( Regex.IsMatch(s, pattern))
                    {
                        double ValueofVariable = variableEvaluator(s);


                        DealWithDouble(ValueofVariable, ValueStack, OperatorStack);
                    }
                    else
                    {
                        throw new ArgumentException();
                    }
                }

            }
            // now that the tokens are finished checks if the right conditions are met to give a result.
            // if there are no operators and one value returns the value
            if(OperatorStack.Count == 0)
            {
               if(ValueStack.Count == 1)
                {
                    return ValueStack.Pop();
                }
                else
                {
                    throw new ArgumentException();
                }
              
            } 
            // if there is one operator a + or a - and two values it evaluates and returns the result else it throws a error
            else if (OperatorStack.Count == 1)
            {
                if(ValueStack.Count == 2)
                {
                    if(OperatorStack.IsOnTop("+") || OperatorStack.IsOnTop("-"))
                    {
                        DealWithAdditionorSubtraction( ValueStack, OperatorStack);
                        return ValueStack.Pop();

                    }
                    

                    else
                    {
                        throw new ArgumentException();
                    }

                }
                else
                {
                    throw new ArgumentException();
                }
            }
            else
            {
                throw new ArgumentException();
            }

            
        }

       
        /// <summary>
        /// This method is used to when an integer character needs to be multiplied or devided. 
        /// </summary>
        /// <param name="OldValue"></param>
        /// <param name="NewValue"></param>
        /// <param name="Operator1"></param>
        /// <returns></returns>
        public static double ManipulateDouble(double OldValue, double NewValue, String Operator1)
        {
          if(Operator1.Equals("*"))
            {
                return OldValue * NewValue;
            }
            else
            {
                if(NewValue == 0)
                {
                    throw new ArgumentException();

                }
                else
                {
                    return OldValue / NewValue;
                }
            }
            
            
            }
        /// <summary>
        /// takes the int that needs to be dealt with and decides if it needs to be pushed into the stack or multiplied or divided by a previous integer
        /// then pushed.
        /// </summary>
        /// <param name="x"></param>
        /// <param name="ValueStack"></param>
        /// <param name="OperatorStack"></param>
        public static void DealWithDouble(double x, Stack<double> ValueStack, Stack<String> OperatorStack )
        {
            
                if (OperatorStack.IsOnTop("*") || OperatorStack.IsOnTop("/"))
                {
                    if (ValueStack.Count < 1)
                    {
                        throw new ArgumentException();
                    }

                    ValueStack.Push(ManipulateDouble(ValueStack.Pop(), x, OperatorStack.Pop()));

                }
                else
                {
                    ValueStack.Push(x);
                }



            
            

        }
        /// <summary>
        /// When numbers needs to be added this program takes the integers and adds or subtracts them.
        /// </summary>
        /// <param name="ValueStack"></param>
        /// <param name="OperatorStack"></param>
        public static void DealWithAdditionorSubtraction( Stack<double> ValueStack, Stack<String> OperatorStack)
        {
            if (ValueStack.Count < 2)
            {
                throw new ArgumentException();
            }
            if (OperatorStack.IsOnTop("+"))
            {
                OperatorStack.Pop();

                ValueStack.Push(ValueStack.Pop() + ValueStack.Pop());
                

            }
            else
            {
                OperatorStack.Pop();
                double x = ValueStack.Pop();
                double y = ValueStack.Pop();
                ValueStack.Push(y - x);

               

            }
            


        }

        /// <summary>
        /// Deals with the case when a multiplication or division occurs linked to a parenthesis such as 9*(7)
        /// makes sure there is two integers in the Value stack then does the required operation throws error if division by zero occurs
        /// or if there is not two values left. 
        /// </summary>
        /// <param name="ValueStack"></param>
        /// <param name="OperatorStack"></param>
        public static void DealWithMultiplicationorDivisionWithParenthesis(Stack<double> ValueStack, Stack<String> OperatorStack)
            {
            if (OperatorStack.Peek().Equals("*") || OperatorStack.Peek().Equals("/"))
            {
                if (ValueStack.Count() >= 2)
                {
                    if (OperatorStack.IsOnTop("*"))
                    {
                        ValueStack.Push(ValueStack.Pop() * ValueStack.Pop());
                    }
                    else
                    {
                        double y = ValueStack.Pop();
                        double x = ValueStack.Pop();
                        if (y == 0)
                        {
                            throw new ArgumentException("Divide by zero error");

                        }
                        else
                        {
                            ValueStack.Push(x / y);
                        }
                    }
                    OperatorStack.Pop();
                }
                else
                {
                    throw new ArgumentException();
                }
            }
        }


    }
}

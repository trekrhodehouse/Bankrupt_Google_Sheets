﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Text.RegularExpressions;
using NetworkUtil;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;


namespace SS
{
    public class SpreadsheetController
    {
        public delegate void InitialMessageHandler(IEnumerable<string> messages);
        public event InitialMessageHandler InitialMessagesArrived;

        public delegate void UpdateMessageHandler(string message);
        public event UpdateMessageHandler UpdateMessageArrived;

        public delegate void SelectionMessageHandler(string message);
        public event SelectionMessageHandler SelectionMessageArrived;

        public delegate void DisconnectMessageHandler(string message);
        public event DisconnectMessageHandler DisconnectMessageArrived;

        public delegate void RequestErrorMessageHandler(string message);
        public event RequestErrorMessageHandler RequestErrorMessageArrived;

        public delegate void ShutdownMessageHandler(string message);
        public event ShutdownMessageHandler ShutdownMessageArrived;

        public delegate void ConnectedHandler();
        public event ConnectedHandler Connected;

        public delegate void ErrorHandler(string err);
        public event ErrorHandler Error;


        private bool selectCheck = false;
        private bool FileCheck = false;
        private bool canSend = false;


        // keeps track of the name of the player
        private string userName;
        // keeps track of the player tank's ID
        private int userID;


        /// <summary>
        /// State representing the connection with the server
        /// </summary>
        SocketState theServer = null;

        public SpreadsheetController()
        {

        }

        /// <summary>
        /// Sets player name to the name typed in the text box.
        /// </summary>
        /// <param name="name"></param>
        public void AssignName(string name)
        {
            userName = name;
        }

        /// <summary>
        /// Begins the process of connecting to the server
        /// </summary>
        /// <param name="addr"></param>
        public void Connect(string addr)
        {
            Networking.ConnectToServer(OnConnect, addr, 1100);
        }
        /// <summary>
        /// Method to be invoked by the networking library when a connection is made
        /// </summary>
        /// <param name="state"></param>
        private void OnConnect(SocketState state)
        {
            if (state.ErrorOccured)
            {
                // inform the view
                Error("Error connecting to server");
                return;
            }

            // inform the view
            Connected();

            theServer = state;

            // send the player's name to the server
            Networking.Send(theServer.TheSocket, userName + "\n");

            // Start an event loop to receive messages from the server
            state.OnNetworkAction = ReceiveMessage;
            Networking.GetData(state);
        }

        public void FileSend(string filename)
        {
            Networking.Send(theServer.TheSocket, filename + "\n");
        }

        /// <summary>
        /// Method to be invoked by the networking library when  data is available
        /// </summary>
        /// <param name="state"></param>
        private void ReceiveMessage(SocketState state)
        {
            if (state.ErrorOccured)
            {
                // inform the view
                Error("Lost connection to server");
                return;
            }
            ProcessMessages(state);

            // Continue the event loop
            Networking.GetData(state);




        }



        /// <summary>
        /// Checks to ensure a received message is a complete JSON wall. Returns false if any of the JSON properties are not present.
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private bool IsCompleteUpdateJSON(string message)
        {
            // messages should end with newline
            if (message[message.Length - 1] == '\n')
            {
                JToken token;
                JObject obj = JObject.Parse(message);

                //Checks to make sure all JTokens necessary to create a wall object are present.
                token = obj["messageType"];
                if (token == null)
                    return false;

                token = obj["cellName"];
                if (token == null)
                    return false;

                token = obj["contents"];
                if (token == null)
                    return false;
            }
            else
            {
                return false;
            }

            // If all tokens are present, returns true.
            return true;
        }

        /// <summary>
        /// Checks to ensure a received message is a complete JSON wall. Returns false if any of the JSON properties are not present.
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private bool IsCompleteServerSelectionJSON(string message)
        {
            // messages should end with newline
            if (message[message.Length - 1] == '\n')
            {
                JToken token;
                JObject obj = JObject.Parse(message);

                //Checks to make sure all JTokens necessary to create a wall object are present.
                token = obj["messageType"];
                if (token == null)
                    return false;

                token = obj["cellName"];
                if (token == null)
                    return false;

                token = obj["selector"];
                if (token == null)
                    return false;

                token = obj["selectorName"];
                if (token == null)
                    return false;
            }
            else
            {
                return false;
            }

            // If all tokens are present, returns true.
            return true;
        }

        /// <summary>
        /// Checks to ensure a received message is a complete JSON wall. Returns false if any of the JSON properties are not present.
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private bool IsCompleteDisconnectJSON(string message)
        {
            // messages should end with newline
            if (message[message.Length - 1] == '\n')
            {
                JToken token;
                JObject obj = JObject.Parse(message);

                //Checks to make sure all JTokens necessary to create a wall object are present.
                token = obj["messageType"];
                if (token == null)
                    return false;

                token = obj["user"];
                if (token == null)
                    return false;


            }
            else
            {
                return false;
            }

            // If all tokens are present, returns true.
            return true;
        }

        private bool IsCompleteRequestErrorJSON(string message)
        {
            // messages should end with newline
            if (message[message.Length - 1] == '\n')
            {
                JToken token;
                JObject obj = JObject.Parse(message);

                //Checks to make sure all JTokens necessary to create a wall object are present.
                token = obj["messageType"];
                if (token == null)
                    return false;

                token = obj["cellName"];
                if (token == null)
                    return false;

                token = obj["message"];
                if (token == null)
                    return false;

            }
            else
            {
                return false;
            }

            // If all tokens are present, returns true.
            return true;
        }

        private bool IsCompleteShutdownJSON(string message)
        {
            // messages should end with newline
            if (message[message.Length - 1] == '\n')
            {
                JToken token;
                JObject obj = JObject.Parse(message);

                //Checks to make sure all JTokens necessary to create a wall object are present.
                token = obj["messageType"];
                if (token == null)
                    return false;

                token = obj["message"];
                if (token == null)
                    return false;

            }
            else
            {
                return false;
            }

            // If all tokens are present, returns true.
            return true;
        }


        public void UpdateSelection(SelectCell selection)
        {
            if (canSend)
            {
                selectCheck = true;
                string message = JsonConvert.SerializeObject(selection);
                Networking.Send(theServer.TheSocket, message + "\n");
            }
        }

        public void SendEdit(EditCellRequest edit)
        {
            if (canSend && selectCheck)
            {
                string message = JsonConvert.SerializeObject(edit);
                Networking.Send(theServer.TheSocket, message + "\n");
            }
        }

        public void RevertSend(RevertRequest revert)
        {
            if (canSend && selectCheck)
            {
                string message = JsonConvert.SerializeObject(revert);
                Networking.Send(theServer.TheSocket, message + "\n");
            }
        }

        public void UndoSend(UndoRequest undo)
        {
            if (canSend && selectCheck)
            {
                string message = JsonConvert.SerializeObject(undo);
                Networking.Send(theServer.TheSocket, message + "\n");
            }
        }


        /// <summary>
        /// Process any buffered messages separated by '\n'
        /// Then inform the view
        /// </summary>
        /// <param name="state"></param>
        private void ProcessMessages(SocketState state)
        {
            string totalData = state.GetData();
            string[] parts = Regex.Split(totalData, @"(?<=[\n])");
            StringBuilder sb = new StringBuilder();
            bool shutdownHelp = true;
            // Loop until we have processed all messages.
            // We may have received more than one.

            List<string> newMessages = new List<string>();
            foreach (string p in parts)
            {
                //Empty string check.
                if (p != "")
                {
                    if (FileCheck && !canSend)
                    {
                        if (Int32.TryParse(p, out int result))
                        {

                            state.RemoveData(0, p.Length);
                            canSend = true;
                        }
                        else
                        {
                            if (IsCompleteUpdateJSON(p))
                            {
                                UpdateMessageArrived(p);
                                state.RemoveData(0, p.Length);
                                continue;
                            }

                        }
                    }
                    //All messages should begin with a '{'.
                    if (p[0] == '{')
                    {
                        //Uses the helper method to check if the message is a complete wall JSON.
                        if (IsCompleteUpdateJSON(p))
                        {
                            UpdateMessageArrived(p);
                            state.RemoveData(0, p.Length);

                        }

                        //Uses the helper method to check if the message is a complete tank JSON.
                        if (IsCompleteServerSelectionJSON(p))
                        {
                            SelectionMessageArrived(p);
                            state.RemoveData(0, p.Length);

                        }

                        //Uses the helper method to check if the message is a complete projectile JSON.
                        if (IsCompleteDisconnectJSON(p))
                        {
                            DisconnectMessageArrived(p);
                            state.RemoveData(0, p.Length);
                        }

                        //Uses the helper method to check if the message is a complete beam JSON.
                        if (IsCompleteRequestErrorJSON(p))
                        {
                            RequestErrorMessageArrived(p);
                            state.RemoveData(0, p.Length);
                            shutdownHelp = false;

                        }

                        //Uses the helper method to check if the message is a complete powerup JSON.
                        if (IsCompleteShutdownJSON(p) && shutdownHelp)
                        {

                            ShutdownMessageArrived(p);
                            state.RemoveData(0, p.Length);
                        }
                        shutdownHelp = true;
                    }

                    else if (!FileCheck)
                    {
                        //If the message isn't in JSON format, the only message we should be receiving is a
                        //list of strings 
                        newMessages.Add(p);

                        // Then remove it from the SocketState's growable buffer
                        state.RemoveData(0, p.Length);
                    }

                }

                // Ignore empty strings added by the regex splitter
                if (p.Length == 0)
                    continue;
                // The regex splitter will include the last string even if it doesn't end with a '\n',
                // So we need to ignore it if this happens. 
                if (p[p.Length - 1] != '\n')
                    break;




            }
            if (!FileCheck)
            {
                //Inform the view of the spreadsheet choices.
                InitialMessagesArrived(newMessages);
                FileCheck = true;
            }
        }

        public void Close()
        {
            theServer?.TheSocket.Close();
        }


    }
}

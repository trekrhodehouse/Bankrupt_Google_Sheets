/*
 * Trek Rhodehouse
 * April 5, 2021
 */

#ifndef STRING_SET_H
#define STRING_SET_H
#include <vector>
#include <iostream>
#include <string>
#include <cstdlib>
#include <sstream>
#include <stack>
namespace SpreadsheetUtilities
{
  class Formula
  {

    std::vector<std::string> TokenStorer;
    
    
  public:
    Formula(std::string formula);
    bool IsValid(std::string variable);
    std::string Normalize(std::string variable);
    bool IsAVariable(std::string token);
    bool IsAValidVariable(std::string token);
    bool IsAnOperator(std::string token);
    int Evaluate ();
    bool is_numeric(std::string const &str);
    double DealWithAdditionorSubtraction(std::stack<double> ValueStack, std::stack<std::string>);
    std::string GetString(char character);
    std::vector<std::string> GetTokens(std::string &Formula);

  };
}
#endif